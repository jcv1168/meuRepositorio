package simulador.serpro.caixa.jwt;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jwt.JWTClaimsSet;

import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class GerarToken {
	private Certificado certificado;
	
	public GerarToken(){
		certificado = new Certificado();
	}
	
	public JWSObject build(Object obj, String issuer, String subject, String name) {

		JWSObject retorno = null;

		try {
			String json = new ObjectMapper().setSerializationInclusion(Include.NON_NULL).writeValueAsString(obj);
			
			JSONParser parser = new JSONParser();
			JSONObject json3 = (JSONObject) parser.parse(json);
			
			JWSSigner signer = new RSASSASigner(Certificado.PRIVKEY);

			JWTClaimsSet propriedades = new JWTClaimsSet.Builder().issuer(issuer).audience("FGTS Digital")
					.issueTime(new Date(new Date().getTime() / 1000 * 1000)).subject(subject)
					.jwtID("602a8257-77c6-4bc2-8bb2-7f8241691391").claim("name", name).claim("dat", json3).build();

			JWSHeader jwsHeader = new JWSHeader.Builder(JWSAlgorithm.RS256)
					.x509CertChain(Certificado.LISTACADEIACERTIFICADO).type(new JOSEObjectType("JWT")).build();

			JWSObject jws = new JWSObject(jwsHeader, new Payload(propriedades.toString()));
			
			jws.sign(signer);
			retorno = jws;
		} catch (JOSEException | JsonProcessingException | ParseException e) {
			e.printStackTrace();
		}
		return retorno;
	}

	public JWSObject build2(String json, String issuer, String subject, String name) {

		JWSObject retorno = null;

		try {
			JSONParser parser = new JSONParser();
			JSONObject json3 = (JSONObject) parser.parse(json);
			
			JWSSigner signer = new RSASSASigner(Certificado.PRIVKEY);

			JWTClaimsSet propriedades = new JWTClaimsSet.Builder().issuer(issuer).audience("FGTS Digital")
					.issueTime(new Date(new Date().getTime() / 1000 * 1000)).subject(subject)
					.jwtID("602a8257-77c6-4bc2-8bb2-7f8241691391").claim("name", name).claim("dat", json3).build();

			JWSHeader jwsHeader = new JWSHeader.Builder(JWSAlgorithm.RS256)
					.x509CertChain(Certificado.LISTACADEIACERTIFICADO).type(new JOSEObjectType("JWT")).build();

			JWSObject jws = new JWSObject(jwsHeader, new Payload(propriedades.toString()));
			
			jws.sign(signer);
			retorno = jws;
		} catch (JOSEException | ParseException e) {
			e.printStackTrace();
		}
		return retorno;
	}
	
}