package simulador.serpro.caixa.jwt;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.List;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.util.Base64;

public class Certificado {

	public static X509Certificate CERTIFICADOASSINANTE;
	public static RSAPrivateKey PRIVKEY;
	public static RSAPublicKey PUBKEY;
	public static List<Base64> LISTACADEIACERTIFICADO;

	public Certificado() {

		String KEY_STORE_TYPE_ENTRY = "pkcs12";
		String KEY_STORE_PWD_ENTRY = "secret";
		String KEY_ALIAS_ENTRY = "signer";

		InputStream is = Certificado.class.getClassLoader().getResourceAsStream("test.pfx");

		try {
			// in = new FileInputStream(new File(KEY_STORE_ENTRY));

			final KeyStore store = KeyStore.getInstance(KEY_STORE_TYPE_ENTRY);
			store.load(is, KEY_STORE_PWD_ENTRY.toCharArray());

			LISTACADEIACERTIFICADO = new ArrayList<>();

			PRIVKEY = (RSAPrivateKey) store.getKey(KEY_ALIAS_ENTRY, KEY_STORE_PWD_ENTRY.toCharArray());
			CERTIFICADOASSINANTE = (X509Certificate) store.getCertificate(KEY_ALIAS_ENTRY);
			PUBKEY = (RSAPublicKey) CERTIFICADOASSINANTE.getPublicKey();
			is.close();

			java.security.cert.Certificate[] certificate = store.getCertificateChain(KEY_ALIAS_ENTRY);

			for (java.security.cert.Certificate lst : certificate) {
				X509Certificate certificadoRetorno = (X509Certificate) lst;

				com.nimbusds.jose.util.Base64 base64Cert = com.nimbusds.jose.util.Base64
						.encode(certificadoRetorno.getEncoded());
				LISTACADEIACERTIFICADO.add(base64Cert);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnrecoverableKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public boolean verficarChavePublica(JWSObject parseToken) throws JOSEException {

		JWSVerifier verificarChave = new RSASSAVerifier(Certificado.PUBKEY);
		return parseToken.verify(verificarChave);
	}

	public boolean verificarCertificadoAssinante(JWSObject parseToken) {

	
		List<Base64> listaCadeiaToken = parseToken.getHeader().getX509CertChain();
		Base64 certificadoAssinante = null;
		boolean chavePublica = false;

		if (listaCadeiaToken == null) return false;
		
		try {
			chavePublica = verficarChavePublica(parseToken);
			certificadoAssinante = Base64.encode(Certificado.CERTIFICADOASSINANTE.getEncoded());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return chavePublica ? listaCadeiaToken.contains(certificadoAssinante) : false;

	}

	public boolean verificarCadeiaCertificado(JWSObject parseToken) {

		List<Base64> listaCadeiaToken = parseToken.getHeader().getX509CertChain();
		List<Base64> listaCadeiaLocal = Certificado.LISTACADEIACERTIFICADO;

		if (listaCadeiaToken == null)	return false;
	
		return listaCadeiaToken.equals(listaCadeiaLocal);

	}
}

