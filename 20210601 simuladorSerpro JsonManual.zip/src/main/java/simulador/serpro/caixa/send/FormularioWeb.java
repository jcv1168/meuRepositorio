package simulador.serpro.caixa.send;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import simulador.serpro.caixa.model.EncargosWeb;
import simulador.serpro.caixa.model.EstornosWeb;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FormularioWeb {

	// Dados de controle
	private String atualizacao;
	private int exclusao;
	// Identificação do empregador
	private String tpEmpregador; 
	private String inscEmpregador;
	// Identificação do trabalhador
	private String idVinculoCef;
	private String cpf;
	private String matricula;
	//private String tsAtualizacao;
	//private String tipo;
	
	// Dados cadastrais do trabalhador
	private String nomeTrabalhador;
	private String nomeSocial;
	private String dtNascimento;
	private String emailTrabalhador;
	private String telTrabalhador;
	// Endereço
	private String tpLogradouro;
	private String dscLogradouro;
	private String numLogradouro;
	private String compLogradouro;
	private String bairro;
	private String cep;
	private String codIbge;
	private String uf;
	// Dados contratuais do trabalhador
	private String categoria;
	private String dtAdmissao;
	private String dtOpcaoFgts;
	private String inscEstabelecimento;
	private String tpInscEstabelecimento;
	private String dtInicioTsve;
	// Admissão por transferência
	private String tpInscricao;
	private String cpfCnpjAntigoEmpregador;
	private String dtTransferencia;
	private String matAntigoEmpregador;
	private String flagInfoMatricula;
	// Admissão mudança de cpf
	private String cpfAnteriorTrab;
	private String matAnteriorTrab;
	private String dtAlteracaoCpf;
	private String flagMudancaCPF;
	// Desligamento
	private String tpDesligamento;
	private String dtDesligamento;
	private String motivoDesligamento;
	private String dataFimTsve;
	private String motivoDesligTsve;
	// Pensão alimentícia
	private String tpPensao;
	private String percentualPensao;
	private String valorPensao;
	// Transferência para outro empragador
	private String tpInscEmpregador;
	private String cnpjNovoEmpregador;
	// Mudança de cpf
	private String cpfNovoTrabalhador;
	// Admissao para desligamento
	private String dataAdmisDeslig;
	// Post, Patch, Put e Delete
	private String btnAction;
	private String ambiente;
	
	/*
	 * Retificação Financeira 
	 * */
	
	// Post, Patch, Put e Delete
	private String btn2Action;
	// Dados de controle
	private String dtArrecadacao;
	
	// Estornos
	private List<EstornosWeb> estornos;
	//Encargos
	private List<EncargosWeb> encargos;
	
	// Protocolo cancelamento
	private String protocoloBloqueio;
	// Delete
	private String btn3Action;
	
	

	public FormularioWeb(){
		this.estornos = new ArrayList<>();
		this.encargos = new ArrayList<>();
	}
	public String getBtn3Action() {
		return btn3Action;
	}

	public void setBtn3Action(String btn3Action) {
		this.btn3Action = btn3Action;
	}

	public String getProtocoloBloqueio() {
		return protocoloBloqueio;
	}

	public void setProtocoloBloqueio(String protocoloBloqueio) {
		this.protocoloBloqueio = protocoloBloqueio;
	}

	public List<EstornosWeb> getEstornos() {
		return estornos;
	}
	public void setEstornos(List<EstornosWeb> estornos) {
		this.estornos = estornos;
	}
	
	public List<EncargosWeb> getEncargos() {
		return encargos;
	}
	public void setEncargos(List<EncargosWeb> encargos) {
		this.encargos = encargos;
	}

	public String getDtArrecadacao() {
		return dtArrecadacao;
	}

	public void setDtArrecadacao(String dtArrecadacao) {
		this.dtArrecadacao = dtArrecadacao;
	}

	public String getDataAdmisDeslig() {
		return dataAdmisDeslig;
	}

	public void setDataAdmisDeslig(String dataAdmisDeslig) {
		this.dataAdmisDeslig = dataAdmisDeslig;
	}

	public String getBtnAction() {
		return btnAction;
	}

	public void setBtnAction(String btnAction) {
		this.btnAction = btnAction;
	}

	public String getInscEstabelecimento() {
		return inscEstabelecimento;
	}

	public void setInscEstabelecimento(String inscEstabelecimento) {
		this.inscEstabelecimento = inscEstabelecimento;
	}

	public String getTpInscEstabelecimento() {
		return tpInscEstabelecimento;
	}

	public void setTpInscEstabelecimento(String tpInscEstabelecimento) {
		this.tpInscEstabelecimento = tpInscEstabelecimento;
	}

	public String getTpDesligamento() {
		return tpDesligamento;
	}

	public void setTpDesligamento(String tpDesligamento) {
		this.tpDesligamento = tpDesligamento;
	}
	
	public String getTpEmpregador() {
		return tpEmpregador;
	}

	public void setTpEmpregador(String tpEmpregador) {
		this.tpEmpregador = tpEmpregador;
	}

	public String getInscEmpregador() {
		return inscEmpregador;
	}

	public void setInscEmpregador(String inscEmpregador) {
		this.inscEmpregador = inscEmpregador;
	}

	public String getIdVinculoCef() {
		return idVinculoCef;
	}

	public void setIdVinculoCef(String idVinculoCef) {
		this.idVinculoCef = idVinculoCef;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getNomeTrabalhador() {
		return nomeTrabalhador;
	}

	public void setNomeTrabalhador(String nomeTrabalhador) {
		this.nomeTrabalhador = nomeTrabalhador;
	}

	public String getNomeSocial() {
		return nomeSocial;
	}

	public void setNomeSocial(String nomeSocial) {
		this.nomeSocial = nomeSocial;
	}

	public String getDtNascimento() {
		return dtNascimento;
	}

	public void setDtNascimento(String dtNascimento) {
		this.dtNascimento = dtNascimento;
	}

	public String getEmailTrabalhador() {
		return emailTrabalhador;
	}

	public void setEmailTrabalhador(String emailTrabalhador) {
		this.emailTrabalhador = emailTrabalhador;
	}

	public String getTelTrabalhador() {
		return telTrabalhador;
	}

	public void setTelTrabalhador(String telTrabalhador) {
		this.telTrabalhador = telTrabalhador;
	}

	public String getTpLogradouro() {
		return tpLogradouro;
	}

	public void setTpLogradouro(String tpLogradouro) {
		this.tpLogradouro = tpLogradouro;
	}

	public String getDscLogradouro() {
		return dscLogradouro;
	}

	public void setDscLogradouro(String dscLogradouro) {
		this.dscLogradouro = dscLogradouro;
	}

	public String getNumLogradouro() {
		return numLogradouro;
	}

	public void setNumLogradouro(String numLogradouro) {
		this.numLogradouro = numLogradouro;
	}

	public String getCompLogradouro() {
		return compLogradouro;
	}

	public void setCompLogradouro(String compLogradouro) {
		this.compLogradouro = compLogradouro;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCodIbge() {
		return codIbge;
	}

	public void setCodIbge(String codIbge) {
		this.codIbge = codIbge;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getDtAdmissao() {
		return dtAdmissao;
	}

	public void setDtAdmissao(String dtAdmissao) {
		this.dtAdmissao = dtAdmissao;
	}

	public String getDtOpcaoFgts() {
		return dtOpcaoFgts;
	}

	public void setDtOpcaoFgts(String dtOpcaoFgts) {
		this.dtOpcaoFgts = dtOpcaoFgts;
	}

	public String getTpInscricao() {
		return tpInscricao;
	}

	public void setTpInscricao(String tpInscricao) {
		this.tpInscricao = tpInscricao;
	}

	public String getCpfCnpjAntigoEmpregador() {
		return cpfCnpjAntigoEmpregador;
	}

	public void setCpfCnpjAntigoEmpregador(String cpfCnpjAntigoEmpregador) {
		this.cpfCnpjAntigoEmpregador = cpfCnpjAntigoEmpregador;
	}

	public String getDtTransferencia() {
		return dtTransferencia;
	}

	public void setDtTransferencia(String dtTransferencia) {
		this.dtTransferencia = dtTransferencia;
	}

	public String getMatAntigoEmpregador() {
		return matAntigoEmpregador;
	}

	public void setMatAntigoEmpregador(String matAntigoEmpregador) {
		this.matAntigoEmpregador = matAntigoEmpregador;
	}

	public String getCpfAnteriorTrab() {
		return cpfAnteriorTrab;
	}

	public void setCpfAnteriorTrab(String cpfAnteriorTrab) {
		this.cpfAnteriorTrab = cpfAnteriorTrab;
	}

	public String getMatAnteriorTrab() {
		return matAnteriorTrab;
	}

	public void setMatAnteriorTrab(String matAnteriorTrab) {
		this.matAnteriorTrab = matAnteriorTrab;
	}

	public String getDtAlteracaoCpf() {
		return dtAlteracaoCpf;
	}

	public void setDtAlteracaoCpf(String dtAlteracaoCpf) {
		this.dtAlteracaoCpf = dtAlteracaoCpf;
	}

	public String getDtDesligamento() {
		return dtDesligamento;
	}

	public void setDtDesligamento(String dtDesligamento) {
		this.dtDesligamento = dtDesligamento;
	}

	public String getMotivoDesligamento() {
		return motivoDesligamento;
	}

	public void setMotivoDesligamento(String motivoDesligamento) {
		this.motivoDesligamento = motivoDesligamento;
	}

	public String getTpPensao() {
		return tpPensao;
	}

	public void setTpPensao(String tpPensao) {
		this.tpPensao = tpPensao;
	}

	public String getPercentualPensao() {
		return percentualPensao;
	}

	public void setPercentualPensao(String percentualPensao) {
		this.percentualPensao = percentualPensao;
	}

	public String getValorPensao() {
		return valorPensao;
	}

	public void setValorPensao(String valorPensao) {
		this.valorPensao = valorPensao;
	}

	public String getDtInicioTsve() {
		return dtInicioTsve;
	}

	public void setDtInicioTsve(String dtInicioTsve) {
		this.dtInicioTsve = dtInicioTsve;
	}

	public String getTpInscEmpregador() {
		return tpInscEmpregador;
	}

	public void setTpInscEmpregador(String tpInscEmpregador) {
		this.tpInscEmpregador = tpInscEmpregador;
	}

	public String getCnpjNovoEmpregador() {
		return cnpjNovoEmpregador;
	}

	public void setCnpjNovoEmpregador(String cnpjNovoEmpregador) {
		this.cnpjNovoEmpregador = cnpjNovoEmpregador;
	}

	public String getCpfNovoTrabalhador() {
		return cpfNovoTrabalhador;
	}

	public void setCpfNovoTrabalhador(String cpfNovoTrabalhador) {
		this.cpfNovoTrabalhador = cpfNovoTrabalhador;
	}
	
	public String getAtualizacao() {
		return atualizacao;
	}

	public void setAtualizacao(String atualizacao) {
		this.atualizacao = atualizacao;
	}

	public int getExclusao() {
		return exclusao;
	}

	public void setExclusao(int exclusao) {
		this.exclusao = exclusao;
	}

	public String getDataFimTsve() {
		return dataFimTsve;
	}

	public void setDataFimTsve(String dataFimTsve) {
		this.dataFimTsve = dataFimTsve;
	}

	public String getMotivoDesligTsve() {
		return motivoDesligTsve;
	}

	public void setMotivoDesligTsve(String motivoDesligTsve) {
		this.motivoDesligTsve = motivoDesligTsve;
	}
	public String getFlagInfoMatricula() {
		return flagInfoMatricula;
	}

	public void setFlagInfoMatricula(String flagInfoMatricula) {
		this.flagInfoMatricula = flagInfoMatricula;
	}

	public String getBtn2Action() {
		return btn2Action;
	}

	public void setBtn2Action(String btn2Action) {
		this.btn2Action = btn2Action;
	}
	
	public String getFlagMudancaCPF() {
		return flagMudancaCPF;
	}
	public void setFlagMudancaCPF(String flagMudancaCPF) {
		this.flagMudancaCPF = flagMudancaCPF;
	}

	public String getAmbiente() {
		return ambiente;
	}

	public void setAmbiente(String ambiente) {
		this.ambiente = ambiente;
	}	
	
}
