package simulador.serpro.caixa.send;

import java.util.ArrayList;
import java.util.List;

import simulador.serpro.caixa.model.ControleRetificacao;
import simulador.serpro.caixa.model.Empregado;
import simulador.serpro.caixa.model.Empregador;
import simulador.serpro.caixa.model.Encargos;
import simulador.serpro.caixa.model.EncargosWeb;
import simulador.serpro.caixa.model.Estornos;
import simulador.serpro.caixa.model.EstornosWeb;

public class RetificacaoFinanceira {

	private ControleRetificacao controle;
	private Empregador empregador;
	private Empregado empregado;
	private List<Estornos> estornos;
	private List<Encargos> encargos;

	public RetificacaoFinanceira() {
		this.estornos = new ArrayList<>();
		this.encargos = new ArrayList<>();
	}
	public ControleRetificacao getControle() {
		return controle;
	}
	public void setControle(ControleRetificacao controle) {
		this.controle = controle;
	}
	public Empregador getEmpregador() {
		return empregador;
	}
	public void setEmpregador(Empregador empregador) {
		this.empregador = empregador;
	}
	public Empregado getEmpregado() {
		return empregado;
	}
	public void setEmpregado(Empregado empregado) {
		this.empregado = empregado;
	}
	
	public List<Estornos> getEstornos() {
		return estornos;
	}
	public void setEstornos(List<Estornos> estornos) {
		this.estornos = estornos;
	}
	public List<Encargos> getEncargos() {
		return encargos;
	}
	public void setEncargos(List<Encargos> encargos) {
		this.encargos = encargos;
	}
	
	public RetificacaoFinanceira formatarEnvio(FormularioWeb formWeb) {
	
		this.controle = new ControleRetificacao();
		this.controle.setArrecadacao(formWeb.getDtArrecadacao());
		
		this.empregador = new Empregador();
		this.empregador.setInscricao(formWeb.getInscEmpregador());
		if(!formWeb.getTpEmpregador().isEmpty()) this.empregador.setTipo(Integer.parseInt(formWeb.getTpEmpregador()));
		
		this.empregado = new Empregado();
		this.empregado.setCpf(formWeb.getCpf());
		this.empregado.setVinculo(formWeb.getIdVinculoCef());
		this.empregado.setMatricula(formWeb.getMatricula());
		
		for (EstornosWeb estornoWeb : formWeb.getEstornos()) {
			Estornos estorno = new Estornos();
			if(!estornoWeb.getCompetencia().isEmpty()) {
				estorno.setCompetencia(estornoWeb.getCompetencia());
				estorno.setTipo(Integer.parseInt(estornoWeb.getTipo()));
				estorno.setMotivo(Integer.parseInt(estornoWeb.getMotivo()));
				estorno.setValor(Float.parseFloat(estornoWeb.getValor()));
				this.estornos.add(estorno); //.items.add(estorno);
			}
		}
		
		for(EncargosWeb encargoWeb: formWeb.getEncargos()) {
			Encargos encargo = new Encargos();
			
			if(!encargoWeb.getCompetencia().isEmpty()) {
				encargo.setCompetencia(encargoWeb.getCompetencia());
				encargo.setCsMensal(Float.parseFloat(encargoWeb.getCsMensal()));
				encargo.setCsRecisorio(Float.parseFloat(encargoWeb.getCsRecisorio()));
				encargo.setEncargos(Float.parseFloat(encargoWeb.getEncargos()));
				encargo.setEncargosCS(Float.parseFloat(encargoWeb.getEncargosCS()));
				this.encargos.add(encargo);//.items.add(encargo);
			}
		}
		
		return this;
	}
	
}
