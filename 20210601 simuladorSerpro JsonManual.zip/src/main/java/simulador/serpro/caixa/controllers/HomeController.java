package simulador.serpro.caixa.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import simulador.serpro.caixa.model.Depositos;
import simulador.serpro.caixa.model.EncargosIndividualizacao;
import simulador.serpro.caixa.model.EncargosWeb;
import simulador.serpro.caixa.model.EstornosWeb;
import simulador.serpro.caixa.model.GuiaRecolhimento;
import simulador.serpro.caixa.model.InfoTrabalhadores;
import simulador.serpro.caixa.model.ManualJson;
import simulador.serpro.caixa.send.FormularioWeb;

@Controller
public class HomeController {
	@RequestMapping("/")
	public ModelAndView index () {		
		ModelAndView mv = new ModelAndView("index");
		mv.addObject("formularioWeb", createFormularioWeb());
		mv.addObject("guiaRecolhimento", createGuia());
		mv.addObject("manualJson", createManualJson());
		return mv;
	}
	
	private ManualJson createManualJson() {
		return new ManualJson("ind");
	}
	
	private FormularioWeb createFormularioWeb() {
		FormularioWeb formularioWeb = new FormularioWeb();
		formularioWeb.setAmbiente("DES");

		//--- retificacao
		EstornosWeb estorno1 = new EstornosWeb();
		EstornosWeb estorno2 = new EstornosWeb();
		EstornosWeb estorno3 = new EstornosWeb();
		formularioWeb.getEstornos().add(estorno1);
		formularioWeb.getEstornos().add(estorno2);
		formularioWeb.getEstornos().add(estorno3);
		
		EncargosWeb encargo1 = new EncargosWeb();
		EncargosWeb encargo2 = new EncargosWeb();
		EncargosWeb encargo3 = new EncargosWeb();
		formularioWeb.getEncargos().add(encargo1);
		formularioWeb.getEncargos().add(encargo2);
		formularioWeb.getEncargos().add(encargo3);
		//--- fim retificacao
		
		return formularioWeb;
	}
	
	private GuiaRecolhimento createGuia() {
		GuiaRecolhimento guiaRecolhimento = new GuiaRecolhimento();
		guiaRecolhimento.setAmbiente("DES");
		
		InfoTrabalhadores infoTrabalhador1 = new InfoTrabalhadores();
		InfoTrabalhadores infoTrabalhador2 = new InfoTrabalhadores();
		InfoTrabalhadores infoTrabalhador3 = new InfoTrabalhadores();
		
		Depositos depositoT1_01 = new Depositos();
		Depositos depositoT1_02 = new Depositos();
		infoTrabalhador1.getDepositos().add(depositoT1_01);
		infoTrabalhador1.getDepositos().add(depositoT1_02);		
		guiaRecolhimento.getIndividualizacoes().add(infoTrabalhador1);
		
		Depositos depositoT2_01 = new Depositos();
		Depositos depositoT2_02 = new Depositos();
		infoTrabalhador2.getDepositos().add(depositoT2_01);
		infoTrabalhador2.getDepositos().add(depositoT2_02);
		guiaRecolhimento.getIndividualizacoes().add(infoTrabalhador2);
		
		Depositos depositoT3_01 = new Depositos();
		Depositos depositoT3_02 = new Depositos();
		infoTrabalhador1.getDepositos().add(depositoT3_01);
		infoTrabalhador1.getDepositos().add(depositoT3_02);
		guiaRecolhimento.getIndividualizacoes().add(infoTrabalhador3);

		EncargosIndividualizacao encargosInd1 = new EncargosIndividualizacao();
		EncargosIndividualizacao encargosInd2 = new EncargosIndividualizacao();
		guiaRecolhimento.getEncargos().add(encargosInd1);
		guiaRecolhimento.getEncargos().add(encargosInd2);
		

		return guiaRecolhimento;
	}
}
