package simulador.serpro.caixa.controllers;

import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import simulador.serpro.caixa.config.Config;
import simulador.serpro.caixa.jwt.GerarToken;
import simulador.serpro.caixa.model.Erro;
import simulador.serpro.caixa.model.GuiaRecolhimento;
import simulador.serpro.caixa.model.RespostaApi;
import simulador.serpro.caixa.util.Util;

@Controller
@RequestMapping("/api")
@RestController
public class guia {

	private GerarToken geraToken = new GerarToken();
	private Util util = new Util();

	private static String URI_DES = new Config().obterConfiguracao().get("url-individualizacao").toString();
	private static String URI_TQS = new Config().obterConfiguracao().get("url-individualizacao-tqs").toString();
	private static String URI_HMP = new Config().obterConfiguracao().get("url-individualizacao-hmp").toString();
	
	private final String ISSUER = "SIT";	
	private final String SUBJECT = "individualizacao";
	private final String NAME = "individualiza";
	
	
	@PostMapping("/guia")
	public ModelAndView individualizar(GuiaRecolhimento guia, BindingResult result) throws JSONException {
		ModelAndView mv = new ModelAndView();
		String uri = null;
		if(result.hasErrors()) {
			mv.addObject("formularioWeb", guia);
			mv.addObject("erro", new Erro(result.getAllErrors().toString()));
			mv.setViewName("error");
		}
		else {
			switch (guia.getAmbiente()) {
			case "DES":
				uri = URI_DES;
				break;
			case "TQS":
				uri = URI_TQS;
				break;
			case "HMP":
				uri = URI_HMP;
				break;
			default:
				break;
			}
			
			String token = geraToken.build(guia, ISSUER, SUBJECT, NAME).serialize();
			String tokenResposta = util.apiSicfd(token, "POST", uri);
			
			String payload = util.getPayLoad(token);
			String payloadResposta = util.getPayLoad(tokenResposta);
			
			RespostaApi respostaApi = new RespostaApi();			
			respostaApi.setResposta(tokenResposta);	
			respostaApi.setPayloadEnvio(payload);
			respostaApi.setPayloadRetorno(payloadResposta);
			respostaApi.setTokenJwt(token);			
			respostaApi.setTokenTipo("(Tipo = Individualização)");
			respostaApi.setUrl("(url = "+uri+")");
			
			mv.addObject("respostaApi", respostaApi);
			mv.setViewName("response");
		}
		return mv;
	}
}
