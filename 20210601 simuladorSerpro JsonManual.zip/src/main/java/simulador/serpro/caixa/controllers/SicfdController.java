package simulador.serpro.caixa.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import simulador.serpro.caixa.config.Config;
import simulador.serpro.caixa.jwt.GerarToken;
import simulador.serpro.caixa.model.Erro;
import simulador.serpro.caixa.model.RespostaApi;
import simulador.serpro.caixa.model.Vinculo;
import simulador.serpro.caixa.send.FormularioWeb;
import simulador.serpro.caixa.util.Util;

@Controller
@RequestMapping("/sicfd/api")
@RestController
public class SicfdController {
	//private Certificado certificado = new Certificado();
	private GerarToken geraToken = new GerarToken();
	private Util util = new Util();
	
	private static String URI_DES = new Config().obterConfiguracao().get("url-vinculo").toString();
	private static String URI_TQS = new Config().obterConfiguracao().get("url-vinculo-tqs").toString();
	private static String URI_HMP = new Config().obterConfiguracao().get("url-vinculo-hmp").toString();
	
	//private final String ORIGEM_CAIXA = "Caixa";
	private final String ORIGEM_SIT = "SIT";	
	private final String SOLICITACAO_VINCULO = "vinculo";
	private final String POST_VINCULO = "novoVinculo";
	private final String PATCH_VINCULO = "atualizaVinculo";
	private final String PUT_VINCULO = "desligaTrabalhador";
	
	@GetMapping("/vinculo")
	public ModelAndView search() {
		
		RespostaApi respostaApi = new RespostaApi();
		ModelAndView mv = new ModelAndView("response");
		respostaApi.setTokenJwt("GET");	
		mv.addObject("respostaApi", respostaApi);
		mv.setViewName("response");
	
		return mv;
	}
	
	@PostMapping("/vinculo")
	public ModelAndView criar(FormularioWeb frmWeb, BindingResult result, HttpSession session) throws JSONException {
		ModelAndView mv = new ModelAndView();
		String uri = null;
		if(result.hasErrors()) {
			mv.addObject("formularioWeb", frmWeb);
			mv.addObject("erro", new Erro(result.getAllErrors().toString()));
			mv.setViewName("error");
		}
		else {
			Vinculo vin = new Vinculo();
			vin.formatarEnvio(frmWeb);
			String action = "";			
			
			switch (frmWeb.getBtnAction()) {
			case "POST":
				action = POST_VINCULO;
				break;
			case "PATCH":
				action = PATCH_VINCULO;
				break;
			case "PUT":
				action = PUT_VINCULO;
				break;
			default:
				break;
			}
			
			session.setAttribute("ambiente", frmWeb.getAmbiente());
			switch (frmWeb.getAmbiente()) {
			case "DES":
				uri = URI_DES;
				break;
			case "TQS":
				uri = URI_TQS;
				break;
			case "HMP":
				uri = URI_HMP;
				break;
			default:
				break;
			}
						
			String token = geraToken.build(vin, ORIGEM_SIT, SOLICITACAO_VINCULO, action).serialize();			
			String tokenResposta = util.apiSicfd(token, frmWeb.getBtnAction(), uri);
			
			String payload = util.getPayLoad(token);
			String payloadResposta = util.getPayLoad(tokenResposta);
			
			RespostaApi respostaApi = new RespostaApi();			
			respostaApi.setResposta(tokenResposta);	
			respostaApi.setPayloadEnvio(payload);
			respostaApi.setPayloadRetorno(payloadResposta);
			respostaApi.setTokenJwt(token);	
			respostaApi.setTokenTipo("(Tipo = Vinculo)");
			respostaApi.setUrl("(url = "+uri+")");
			
			mv.addObject("respostaApi", respostaApi);
			mv.setViewName("response");
		}
		return mv;
	}
	
    @RequestMapping({"/"})
    String index(HttpSession session) {
        session.setAttribute("mySessionAttribute", "someValue");
        return "index";
    }
}
