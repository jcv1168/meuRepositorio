package simulador.serpro.caixa.util;

import java.util.Base64;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

public class Util {
	
	 @Bean
	 public RestTemplate restTemplate() {
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setReadTimeout(600000);
		requestFactory.setConnectTimeout(600000);
		return new RestTemplate(requestFactory);
	 }
	 
	public HttpHeaders buildHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-type","text/plain");
		
		return headers;
	}
	
	public String apiSicfd(String token, String verb, String uri) {
		String resp = "error...";
		
		HttpEntity<String> request = new HttpEntity<String>(token, buildHeaders());

		try {
			switch (verb) {
			case "PUT":			   
			      resp = restTemplate().exchange(uri, HttpMethod.PUT, request, String.class).getBody();
				break;
			case "PATCH":
				resp = restTemplate().patchForObject(uri, request, String.class).toString();
				break;
			case "POST":
				resp = restTemplate().postForObject(uri, request, String.class).toString();
				break;
			case "DELETE":
				resp = restTemplate().exchange(uri, HttpMethod.DELETE, request, String.class).getBody();
				break;
			}
		} catch (HttpStatusCodeException ex){
			resp = ex.getResponseBodyAsString(); // Nao mudar, pois a resposta da API vem no Body
			System.out.println(ex);
		} catch (Exception ex) {
			resp = ex.getMessage();
			System.out.println(ex);
		}
		
		return resp;
	}
	
	public String getPayLoad(String token) {
		String resultado = "";
		int p1 = token.indexOf('.');
		String payload = token.substring(p1+1);		
		int p2 = payload.indexOf('.');
		
		try {
			resultado = decodeBase64(token.substring(p1+1, (p1+p2+1)));
		} catch (Exception e) {
			// TODO: handle exception
		}
		return resultado;
	}
	
	private String decodeBase64(String aux) {
        byte[] bytes = Base64.getDecoder().decode(aux);
        return new String(bytes);
	}
}
