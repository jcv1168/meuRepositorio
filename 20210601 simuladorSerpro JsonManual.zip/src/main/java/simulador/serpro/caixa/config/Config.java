package simulador.serpro.caixa.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Config {

public Properties obterConfiguracao() {
		
		Properties prop = new Properties();
		InputStream config;
		
		try {
			/** Quando executado dentro do projeto, escolher um local para o arquivo de properties e alterar o local. **/			
			config =  new FileInputStream("C:\\TEMP\\fgts\\config\\config.txt");//("/home/alan/Downloads/FGTS-digital/config.txt");  
			prop.load(config);
			
		}catch(Exception e){
			
			try {
				/** Quando executado JAR, vai detectar o local onde o arquivo jar esta, localizando e ira buscar o diretorio "config". **/
				ClassLoader loader = getClass().getClassLoader();
				File file = new File(loader.getResource("config/config.txt").getFile());  // Quando executado pelo arquivo .jar
				config = new FileInputStream(file);
				prop.load(config);
				
			} catch (FileNotFoundException e1) {
				System.out.println("O arquivo de configuracao nao esta na pasta\"Config\" ");
			} catch (IOException e1) {
				System.out.println("O arquivo de configuracao nao esta na pasta\"Config\" ");
			} catch (NullPointerException e1) {
				System.out.println("O arquivo de configuracao nao esta na pasta\"Config\" ");
			}
		}
		return prop;
	}

}
