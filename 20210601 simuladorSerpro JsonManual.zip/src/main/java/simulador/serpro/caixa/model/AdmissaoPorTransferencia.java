package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AdmissaoPorTransferencia {

	public Empregador antigoEmpregador;
	private String ocorrencia;
	private String matriculaAnterior;
	private int flag;
	
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public Empregador getAntigoEmpregador() {
		return antigoEmpregador;
	}
	public void setAntigoEmpregador(Empregador antigoEmpregador) {
		this.antigoEmpregador = antigoEmpregador;
	}
	public String getOcorrencia() {
		return ocorrencia;
	}
	public void setOcorrencia(String ocorrencia) {
		this.ocorrencia = ocorrencia;
	}
	public String getMatriculaAnterior() {
		return matriculaAnterior;
	}
	public void setMatriculaAnterior(String matriculaAnterior) {
		this.matriculaAnterior = matriculaAnterior;
	}
}
