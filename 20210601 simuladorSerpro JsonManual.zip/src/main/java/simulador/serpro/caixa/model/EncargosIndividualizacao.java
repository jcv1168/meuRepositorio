package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class EncargosIndividualizacao {

	private String competencia;
	private int tipo;
	private float encargos;
	private float valorCS;
	private float encargosCS;
	
	public String getCompetencia() {
		return competencia;
	}
	public void setCompetencia(String competencia) {
		this.competencia = competencia;
	}
	public int getTipo() {
		return tipo;
	}
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	public float getEncargos() {
		return encargos;
	}
	public void setEncargos(float encargos) {
		this.encargos = encargos;
	}
	public float getValorCS() {
		return valorCS;
	}
	public void setValorCS(float valorCS) {
		this.valorCS = valorCS;
	}
	public float getEncargosCS() {
		return encargosCS;
	}
	public void setEncargosCS(float encargosCS) {
		this.encargosCS = encargosCS;
	}

	
}
