package simulador.serpro.caixa.model;

public class Erro {

	private String descricao;

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public Erro(String desc) {
		this.descricao = desc;
	}
}
