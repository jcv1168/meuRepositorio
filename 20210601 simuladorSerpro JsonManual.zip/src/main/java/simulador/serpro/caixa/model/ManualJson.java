package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ManualJson {

	private String manualJson;
	private String tokenType;
	@JsonIgnore
	private String ambiente;
	
	public ManualJson(String tokenType) {
		this.tokenType = tokenType;
	}
	
	
	public String getTokenType() {
		return tokenType;
	}

	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}

	public String getManualJson() {
		return manualJson;
	}

	public void setManualJson(String manualJson) {
		this.manualJson = manualJson;
	}
	
	public String getAmbiente() {
		return ambiente;
	}

	public void setAmbiente(String ambiente) {
		this.ambiente = ambiente;
	}
}
