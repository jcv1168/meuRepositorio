package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AdmissaoPorMudancaCPF {

	private String cpfAnterior;
	private String matriculaAnterior;
	private String ocorrencia;
	private int flag;
	
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public String getCpfAnterior() {
		return cpfAnterior;
	}
	public void setCpfAnterior(String cpfAnterior) {
		this.cpfAnterior = cpfAnterior;
	}
	public String getMatriculaAnterior() {
		return matriculaAnterior;
	}
	public void setMatriculaAnterior(String matriculaAnterior) {
		this.matriculaAnterior = matriculaAnterior;
	}
	public String getOcorrencia() {
		return ocorrencia;
	}
	public void setOcorrencia(String ocorrencia) {
		this.ocorrencia = ocorrencia;
	}
	
}
