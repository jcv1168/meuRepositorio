package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class EncargosWeb{
	
	private String competencia;
	private String encargos;
	private String csMensal;
	private String csRecisorio;
	private String encargosCS;
	
	public String getCompetencia() {
		return competencia;
	}
	public void setCompetencia(String competencia) {
		this.competencia = competencia;
	}
	public String getEncargos() {
		return encargos;
	}
	public void setEncargos(String encargos) {
		this.encargos = encargos;
	}
	public String getCsMensal() {
		return csMensal;
	}
	public void setCsMensal(String csMensal) {
		this.csMensal = csMensal;
	}
	public String getCsRecisorio() {
		return csRecisorio;
	}
	public void setCsRecisorio(String csRecisorio) {
		this.csRecisorio = csRecisorio;
	}
	public String getEncargosCS() {
		return encargosCS;
	}
	public void setEncargosCS(String encargosCS) {
		this.encargosCS = encargosCS;
	}
	
	
}
