package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ControleRetificacao {

	private String arrecadacao;

	public String getArrecadacao() {
		return arrecadacao;
	}

	public void setArrecadacao(String arrecadacao) {
		this.arrecadacao = arrecadacao;
	}
	
}
