package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RespostaApi {

	private String resposta;
	private String tokenJwt;
	private String url;
	private String tokenTipo;
	private String payloadEnvio;
	private String payloadRetorno;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getResposta() {
		return resposta;
	}

	public void setResposta(String resposta) {
		this.resposta = resposta;
	}

	public String getTokenJwt() {
		return tokenJwt;
	}

	public void setTokenJwt(String tokenJwt) {
		this.tokenJwt = tokenJwt;
	}

	public String getTokenTipo() {
		return tokenTipo;
	}

	public void setTokenTipo(String tokenTipo) {
		this.tokenTipo = tokenTipo;
	}

	public String getPayloadEnvio() {
		return payloadEnvio;
	}

	public void setPayloadEnvio(String payloadEnvio) {
		this.payloadEnvio = payloadEnvio;
	}

	public String getPayloadRetorno() {
		return payloadRetorno;
	}

	public void setPayloadRetorno(String payloadRetorno) {
		this.payloadRetorno = payloadRetorno;
	}


	
}
