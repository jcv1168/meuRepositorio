package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 * Schema JSON
 * "estornos": {
 *		"description": "Bloqueio para estorno",
 *		"type": "array",
 *		"items": {
 *			"anyOf": [
 *				{
 *					"description": "Bloqueio a realizar",
 *					"type": "object",
 *					"properties": {
 *						"competencia": {
 *							"description": "Mês de competência de referência",
 *							"type": "string",
 *							"pattern": "^2\\d{3}-(0[1-9]|1[012])$"
 *						},
 *						"tipo": {
 *							"description": "Tipo de depósito, onde: 1: mensal, 2: rescisório, 3: verbas indenizatórias e 4: multa rescisória",
 *							"type": "integer",
 *							"enum": [ 1, 2, 3, 4 ]
 *						},
 *						"motivo": {
 *							"description": "Motivo do bloqueio (a ser mapeado)",
 *							"type": "integer"
 *						},
 *						"valor": {
 *							"description": "Valor a ser bloqueado",
 *							"type": "number",
 *							"exclusiveMinimum": 0.0
 *						}
 *					},
 *					"required": [ "competencia", "tipo", "motivo", "valor" ],
 *					"additionalProperties": false
 *				}
 *			]
 *		},
 *		"additionalItems": false
 *	}
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Estornos{

	
	private String competencia;
	private int tipo;
	private int motivo;
	private float valor;
	
	public String getCompetencia() {
		return competencia;
	}
	public void setCompetencia(String competencia) {
		this.competencia = competencia;
	}
	public int getTipo() {
		return tipo;
	}
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	public int getMotivo() {
		return motivo;
	}
	public void setMotivo(int motivo) {
		this.motivo = motivo;
	}
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}
	
}
