package simulador.serpro.caixa.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class GuiaRecolhimento {

	private ControleIndividualizacao controle;
	private Identificacao identificacao;
	private Pix pix;
	private Totalizadores totalizadores;
	private Empregador pessoa;
	public List<InfoTrabalhadores> individualizacoes;
	public List<EncargosIndividualizacao> encargos;
	
	@JsonIgnore
	private String ambiente;
	
	public String getAmbiente() {
		return ambiente;
	}

	public void setAmbiente(String ambiente) {
		this.ambiente = ambiente;
	}

	public GuiaRecolhimento() {	
		this.individualizacoes = new ArrayList<>();
		this.encargos = new ArrayList<>();
	}
	
	public ControleIndividualizacao getControle() {
		return controle;
	}
	public void setControle(ControleIndividualizacao controle) {
		this.controle = controle;
	}
	public Identificacao getIdentificacao() {
		return identificacao;
	}
	public void setIdentificacao(Identificacao identificacao) {
		this.identificacao = identificacao;
	}
	public Pix getPix() {
		return pix;
	}
	public void setPix(Pix pix) {
		this.pix = pix;
	}
	public Totalizadores getTotalizadores() {
		return totalizadores;
	}
	public void setTotalizadores(Totalizadores totalizadores) {
		this.totalizadores = totalizadores;
	}
	public Empregador getPessoa() {
		return pessoa;
	}
	public void setPessoa(Empregador pessoa) {
		this.pessoa = pessoa;
	}

	public List<EncargosIndividualizacao> getEncargos() {
		return encargos;
	}

	public void setEncargos(List<EncargosIndividualizacao> encargos) {
		this.encargos = encargos;
	}

	public List<InfoTrabalhadores> getIndividualizacoes() {
		return individualizacoes;
	}

	public void setIndividualizacoes(List<InfoTrabalhadores> individualizacoes) {
		this.individualizacoes = individualizacoes;
	}

	
}
