package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class Totalizadores {
	
	private int vinculos;
	private float mensal;
	private float rescisorio;
	private float indenizatorias;
	private float multaRescisoria;
	private float principal;
	private float encargos;
	private float csMensal;
	private float csRescisoria;
	private float encargosCS;
	private float devido;
	private float bloqueado;
	private float recolhimento;
	private float creditoCVE;
	
	public int getVinculos() {
		return vinculos;
	}
	public void setVinculos(int vinculos) {
		this.vinculos = vinculos;
	}
	public float getMensal() {
		return mensal;
	}
	public void setMensal(float mensal) {
		this.mensal = mensal;
	}
	public float getRescisorio() {
		return rescisorio;
	}
	public void setRescisorio(float rescisorio) {
		this.rescisorio = rescisorio;
	}
	public float getIndenizatorias() {
		return indenizatorias;
	}
	public void setIndenizatorias(float indenizatorias) {
		this.indenizatorias = indenizatorias;
	}
	public float getMultaRescisoria() {
		return multaRescisoria;
	}
	public void setMultaRescisoria(float multaRescisoria) {
		this.multaRescisoria = multaRescisoria;
	}
	public float getPrincipal() {
		return principal;
	}
	public void setPrincipal(float principal) {
		this.principal = principal;
	}
	public float getEncargos() {
		return encargos;
	}
	public void setEncargos(float encargos) {
		this.encargos = encargos;
	}
	public float getCsMensal() {
		return csMensal;
	}
	public void setCsMensal(float csMensal) {
		this.csMensal = csMensal;
	}
	public float getCsRescisoria() {
		return csRescisoria;
	}
	public void setCsRescisoria(float csRescisoria) {
		this.csRescisoria = csRescisoria;
	}
	public float getEncargosCS() {
		return encargosCS;
	}
	public void setEncargosCS(float encargosCS) {
		this.encargosCS = encargosCS;
	}
	public float getDevido() {
		return devido;
	}
	public void setDevido(float devido) {
		this.devido = devido;
	}
	public float getBloqueado() {
		return bloqueado;
	}
	public void setBloqueado(float bloqueado) {
		this.bloqueado = bloqueado;
	}
	public float getRecolhimento() {
		return recolhimento;
	}
	public void setRecolhimento(float recolhimento) {
		this.recolhimento = recolhimento;
	}
	public float getCreditoCVE() {
		return creditoCVE;
	}
	public void setCreditoCVE(float creditoCVE) {
		this.creditoCVE = creditoCVE;
	}
	
}
