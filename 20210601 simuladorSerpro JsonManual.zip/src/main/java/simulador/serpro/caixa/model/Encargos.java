package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * 
 * Schema JSON
 *
 * "encargos": {
 *		"description": "Bloqueio de encargos para estorno",
 *		"type": "array",
 *		"items": {
 *			"anyOf": [
 *				{
 *					"description": "Encargos a bloquear",
 *					"type": "object",
 *					"properties": {
 *						"competencia": {
 *							"description": "Mês de competência do recolhimento",
 *							"type": "string",
 *							"pattern": "^2\\d{3}-(0[1-9]|1[012])$"
 *						},
 *						"encargos": {
 *							"description": "Valord de encargos do FGTS",
 *							"type": "number",
 *							"minimum": 0.0
 *						},
 *						"csMensal": {
 *							"description": "Valor de CS Mensal",
 *							"type": "number",
 *							"minimum": 0.0
 *						},
 *						"csRescisorio": {
 *							"description": "Valor de CS rescisório",
 *							"type": "number",
 *							"minimum": 0.0
 *						},
 *						"encargosCS": {
 *							"description": "Valor de encargos CS",
 *							"type": "number",
 *							"minimum": 0.0
 *						}
 *					},
 *					"required": [ "competencia", "encargos", "csMensal", "csRescisorio", "encargosCS" ],
 *					"additionalProperties": false
 *				}
 *			]
 *		},
 *		"additionalItems": false
 *	}
 */

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class Encargos{
	
	private String competencia;
	private float encargos;
	private float csMensal;
	private float csRecisorio;
	private float encargosCS;
	
	public String getCompetencia() {
		return competencia;
	}
	public void setCompetencia(String competencia) {
		this.competencia = competencia;
	}
	public float getEncargos() {
		return encargos;
	}
	public void setEncargos(float encargos) {
		this.encargos = encargos;
	}
	public float getCsMensal() {
		return csMensal;
	}
	public void setCsMensal(float csMensal) {
		this.csMensal = csMensal;
	}
	public float getCsRecisorio() {
		return csRecisorio;
	}
	public void setCsRecisorio(float csRecisorio) {
		this.csRecisorio = csRecisorio;
	}
	public float getEncargosCS() {
		return encargosCS;
	}
	public void setEncargosCS(float encargosCS) {
		this.encargosCS = encargosCS;
	}	
	
}
