package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Desligamento {

	private int tipo;
	private String ocorrencia;
	private String motivoTSVE;
	private String fimTSVE;
	private String motivo;
	public Pensao pensao;
	
	public Pensao getPensao() {
		return pensao;
	}
	public void setPensao(Pensao pensao) {
		this.pensao = pensao;
	}
	public String getFimTSVE() {
		return fimTSVE;
	}
	public void setFimTSVE(String fimTSVE) {
		this.fimTSVE = fimTSVE;
	}
	public String getMotivo() {
		return motivo;
	}
	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}
	public int getTipo() {
		return tipo;
	}
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	public String getOcorrencia() {
		return ocorrencia;
	}
	public void setOcorrencia(String ocorrencia) {
		this.ocorrencia = ocorrencia;
	}
	public String getMotivoTSVE() {
		return motivoTSVE;
	}
	public void setMotivoTSVE(String motivoTSVE) {
		this.motivoTSVE = motivoTSVE;
	}
	
	
}
