package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Controle {

	private String atualizacao;
	private int exclusao;
	
	public String getAtualizacao() {
		return atualizacao;
	}
	public void setAtualizacao(String autalizacao) {
		this.atualizacao = autalizacao;
	}
	public int getExclusao() {
		return exclusao;
	}
	public void setExclusao(int exclusao) {
		this.exclusao = exclusao;
	}
	
}
