package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransferenciaEmpregador {

	private Empregador novoEmpregador;

	public Empregador getNovoEmpregador() {
		return novoEmpregador;
	}

	public void setNovoEmpregador(Empregador novoEmpregador) {
		this.novoEmpregador = novoEmpregador;
	}
	
	public TransferenciaEmpregador() {
		this.novoEmpregador = new Empregador();
	}
	
}
