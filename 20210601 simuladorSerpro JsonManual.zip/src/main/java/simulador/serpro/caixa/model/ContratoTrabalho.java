package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContratoTrabalho {

	private String categoria;
	private String admissao;
	private String opcao;
	public Empregador estabelecimento;
	private String inicioTSVE;
	
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getAdmissao() {
		return admissao;
	}
	public void setAdmissao(String dataAdmissao) {
		this.admissao = dataAdmissao;
	}
	public String getOpcao() {
		return opcao;
	}
	public void setOpcao(String dataOpcaoFgts) {
		this.opcao = dataOpcaoFgts;
	}
	public String getInicioTSVE() {
		return inicioTSVE;
	}
	public void setInicioTSVE(String inicioTSVE) {
		this.inicioTSVE = inicioTSVE;
	}
	public Empregador getEstabelecimento() {
		return estabelecimento;
	}
	public void setEstabelecimento(Empregador estabelecimento) {
		this.estabelecimento = estabelecimento;
	}
	
}
