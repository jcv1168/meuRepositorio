package simulador.serpro.caixa.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Pensao {

	//private float percentual; --> alterei para string para não sair no json, pois estava indo 0
	//private float valor;
	private int pensao;
	private String percentual;
	private String valor;	

	public int getPensao() {
		return pensao;
	}
	public void setPensao(int pensao) {
		this.pensao = pensao;
	}
	public String getPercentual() {
		return percentual;
	}
	public void setPercentual(String percentual) {
		this.percentual = percentual;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	
}
