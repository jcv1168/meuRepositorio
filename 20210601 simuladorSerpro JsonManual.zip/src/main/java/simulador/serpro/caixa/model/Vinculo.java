package simulador.serpro.caixa.model;

import simulador.serpro.caixa.send.FormularioWeb;

public class Vinculo {

	private Controle controle;
	private Empregador empregador;
	private Empregado empregado;
	private InfoEmpregado cadastro;
	private ContratoTrabalho contrato;
	private AdmissaoPorTransferencia admissaoPorTransferencia;
	private AdmissaoPorMudancaCPF admissaoPorMudancaCPF;
	private Desligamento desligamento;
	private TransferenciaEmpregador desligamentoPorTransferencia;
	private DesligamentoPorMudancaCPF desligamentoPorMudancaCPF;
	private AdmissaoParaRemuneracao admissaoParaRemuneracao;
	
	
	public Controle getControle() {
		return controle;
	}
	public void setControle(Controle controle) {
		this.controle = controle;
	}
	public Empregador getEmpregador() {
		return empregador;
	}
	public void setEmpregador(Empregador empregador) {
		this.empregador = empregador;
	}
	public Empregado getEmpregado() {
		return empregado;
	}
	public void setEmpregado(Empregado empregado) {
		this.empregado = empregado;
	}
	public InfoEmpregado getCadastro() {
		return cadastro;
	}
	public void setCadastro(InfoEmpregado cadastro) {
		this.cadastro = cadastro;
	}
	public AdmissaoPorTransferencia getAdmissaoPorTransferencia() {
		return admissaoPorTransferencia;
	}
	public void setAdmissaoPorTransferencia(AdmissaoPorTransferencia admissaoPorTransferencia) {
		this.admissaoPorTransferencia = admissaoPorTransferencia;
	}
	public AdmissaoPorMudancaCPF getAdmissaoPorMudancaCPF() {
		return admissaoPorMudancaCPF;
	}
	public void setAdmissaoPorMudancaCPF(AdmissaoPorMudancaCPF admissaoPorMudancaCPF) {
		this.admissaoPorMudancaCPF = admissaoPorMudancaCPF;
	}
	public Desligamento getDesligamento() {
		return desligamento;
	}
	public void setDesligamento(Desligamento desligamento) {
		this.desligamento = desligamento;
	}
	public DesligamentoPorMudancaCPF getDesligamentoPorMudancaCPF() {
		return desligamentoPorMudancaCPF;
	}
	public void setDesligamentoPorMudancaCPF(DesligamentoPorMudancaCPF desligamentoPorMudancaCPF) {
		this.desligamentoPorMudancaCPF = desligamentoPorMudancaCPF;
	}
	public AdmissaoParaRemuneracao getAdmissaoParaRemuneracao() {
		return admissaoParaRemuneracao;
	}
	public void setAdmissaoParaRemuneracao(AdmissaoParaRemuneracao admissaoParaRemuneracao) {
		this.admissaoParaRemuneracao = admissaoParaRemuneracao;
	}
	public ContratoTrabalho getContrato() {
		return contrato;
	}
	public void setContrato(ContratoTrabalho contrato) {
		this.contrato = contrato;
	}	
	public TransferenciaEmpregador getDesligamentoPorTransferencia() {
		return desligamentoPorTransferencia;
	}
	public void setDesligamentoPorTransferencia(TransferenciaEmpregador desligamentoPorTransferencia) {
		this.desligamentoPorTransferencia = desligamentoPorTransferencia;
	}
	
	
	public Vinculo() {}
	
	public Vinculo formatarEnvio(FormularioWeb formWeb) {
		
		this.controle = new Controle();
		this.controle.setExclusao(formWeb.getExclusao());
		this.controle.setAtualizacao(formWeb.getAtualizacao());
		
		this.empregador = new Empregador();
		this.empregador.setInscricao(formWeb.getInscEmpregador());
		if(!formWeb.getTpEmpregador().isEmpty()) this.empregador.setTipo(Integer.parseInt(formWeb.getTpEmpregador()));
		
		this.empregado = new Empregado();
		if(!formWeb.getCpf().isEmpty()) this.empregado.setCpf(formWeb.getCpf());
		this.empregado.setVinculo(formWeb.getIdVinculoCef());
		this.empregado.setMatricula(formWeb.getMatricula());
		
		if (!(formWeb.getNomeTrabalhador() == null) && !formWeb.getNomeTrabalhador().isEmpty()) {
			this.cadastro = new InfoEmpregado();
			this.cadastro.setNome(formWeb.getNomeTrabalhador());
			this.cadastro.setNascimento(formWeb.getDtNascimento());
			if(!formWeb.getNomeSocial().isEmpty()) this.cadastro.setNomeSocial(formWeb.getNomeSocial());
			
			if(!formWeb.getTelTrabalhador().isEmpty()) this.cadastro.setTelefone(formWeb.getTelTrabalhador());
			if(!formWeb.getEmailTrabalhador().isEmpty()) this.cadastro.setEmail(formWeb.getEmailTrabalhador());
			
			if(!(formWeb.getTpLogradouro().isEmpty()) || !(formWeb.getDscLogradouro().isEmpty())) {
				this.cadastro.endereco = new Endereco();
				if(!formWeb.getTpLogradouro().isEmpty()) this.cadastro.endereco.setTipo(formWeb.getTpLogradouro());
				this.cadastro.endereco.setLogradouro(formWeb.getDscLogradouro());
				if(!formWeb.getNumLogradouro().isEmpty()) this.cadastro.endereco.setNumero(formWeb.getNumLogradouro());
				if(!formWeb.getCompLogradouro().isEmpty()) this.cadastro.endereco.setComplemento(formWeb.getCompLogradouro());
				if(!formWeb.getBairro().isEmpty()) this.cadastro.endereco.setBairro(formWeb.getBairro());
				if(!formWeb.getCep().isEmpty()) this.cadastro.endereco.setCep(formWeb.getCep());
				if(!formWeb.getCodIbge().isEmpty()) this.cadastro.endereco.setMunicipio(formWeb.getCodIbge());
				this.cadastro.endereco.setUf(formWeb.getUf());
			}
		}
		
		if(!(formWeb.getCategoria() == null) && !formWeb.getCategoria().isEmpty()) {
			this.contrato = new ContratoTrabalho();
			this.contrato.setCategoria(formWeb.getCategoria());
			if(!formWeb.getDtAdmissao().isEmpty()) this.contrato.setAdmissao(formWeb.getDtAdmissao());
			if(!formWeb.getDtOpcaoFgts().isEmpty()) this.contrato.setOpcao(formWeb.getDtOpcaoFgts());
			if(!formWeb.getDtInicioTsve().isEmpty()) this.contrato.setInicioTSVE(formWeb.getDtInicioTsve());
		}
		
		if(!(formWeb.getInscEstabelecimento() == null) && !formWeb.getInscEstabelecimento().isEmpty()) {
			if(this.contrato == null) this.contrato = new ContratoTrabalho();
			this.contrato.estabelecimento = new Empregador();
			if(!formWeb.getTpInscEstabelecimento().isEmpty()) this.contrato.estabelecimento.setTipo(Integer.parseInt(formWeb.getTpInscEstabelecimento()));
			if(!formWeb.getInscEstabelecimento().isEmpty()) this.contrato.estabelecimento.setInscricao(formWeb.getInscEstabelecimento());
		}
		
		if(!(formWeb.getTpInscricao() == null) && !formWeb.getTpInscricao().isEmpty()) {
			this.admissaoPorTransferencia = new AdmissaoPorTransferencia();		
			this.admissaoPorTransferencia.setOcorrencia(formWeb.getDtTransferencia());
			this.admissaoPorTransferencia.setMatriculaAnterior(formWeb.getMatAntigoEmpregador());
			if(!formWeb.getFlagInfoMatricula().isEmpty()) this.admissaoPorTransferencia.setFlag(Integer.parseInt(formWeb.getFlagInfoMatricula()));
			
			this.admissaoPorTransferencia.antigoEmpregador = new Empregador();
			if(!formWeb.getTpInscricao().isEmpty()) this.admissaoPorTransferencia.antigoEmpregador.setTipo(Integer.parseInt(formWeb.getTpInscricao()));
			if(!formWeb.getCpfCnpjAntigoEmpregador().isEmpty()) this.admissaoPorTransferencia.antigoEmpregador.setInscricao(formWeb.getCpfCnpjAntigoEmpregador());
		}
		
		if(!(formWeb.getCpfAnteriorTrab() == null) && !formWeb.getCpfAnteriorTrab().isEmpty()) {
			this.admissaoPorMudancaCPF =  new AdmissaoPorMudancaCPF();
			this.admissaoPorMudancaCPF.setCpfAnterior(formWeb.getCpfAnteriorTrab());
			this.admissaoPorMudancaCPF.setMatriculaAnterior(formWeb.getMatAnteriorTrab());
			this.admissaoPorMudancaCPF.setOcorrencia(formWeb.getDtAlteracaoCpf());
			if(!formWeb.getFlagMudancaCPF().isEmpty()) this.admissaoPorMudancaCPF.setFlag(Integer.parseInt(formWeb.getFlagMudancaCPF()));
		}
		
		if (!(formWeb.getTpDesligamento() == null) && !formWeb.getTpDesligamento().isEmpty()) {
			this.desligamento = new Desligamento();
			this.desligamento.setTipo(Integer.parseInt(formWeb.getTpDesligamento()));
			
			if(!formWeb.getDtDesligamento().isEmpty()) this.desligamento.setOcorrencia(formWeb.getDtDesligamento());
			if(!formWeb.getMotivoDesligamento().isEmpty()) this.desligamento.setMotivo(formWeb.getMotivoDesligamento());
			
			if(!formWeb.getDataFimTsve().isEmpty())this.desligamento.setFimTSVE(formWeb.getDataFimTsve());
			if(!formWeb.getMotivoDesligTsve().isEmpty()) this.desligamento.setMotivoTSVE(formWeb.getMotivoDesligTsve());
			
			this.desligamento.pensao = new Pensao();
			if(!formWeb.getTpPensao().isEmpty()) this.desligamento.pensao.setPensao(Integer.parseInt(formWeb.getTpPensao()));
			if(!formWeb.getPercentualPensao().isEmpty()) this.desligamento.pensao.setPercentual(formWeb.getPercentualPensao());
			if(!formWeb.getValorPensao().isEmpty()) this.desligamento.pensao.setValor(formWeb.getValorPensao());
		}
		
		if(!(formWeb.getCpfNovoTrabalhador() == null) && !formWeb.getCpfNovoTrabalhador().isEmpty()) {
			this.desligamentoPorMudancaCPF = new DesligamentoPorMudancaCPF();
			this.desligamentoPorMudancaCPF.setNovoCPF(formWeb.getCpfNovoTrabalhador());
		}
		
		if(!(formWeb.getDataAdmisDeslig() == null)&& !formWeb.getDataAdmisDeslig().isEmpty()) {
			this.admissaoParaRemuneracao = new AdmissaoParaRemuneracao();
			this.admissaoParaRemuneracao.setDataDesligamento(formWeb.getDataAdmisDeslig());
		}
		
		if(!(formWeb.getTpInscEmpregador() == null)&& !formWeb.getTpInscEmpregador().isEmpty()) {
			this.desligamentoPorTransferencia = new TransferenciaEmpregador();
			this.desligamentoPorTransferencia.getNovoEmpregador().setInscricao(formWeb.getCnpjNovoEmpregador());
			this.desligamentoPorTransferencia.getNovoEmpregador().setTipo(Integer.parseInt(formWeb.getTpInscEmpregador()));
		}
		
		return this;
	}
}
