package simulador.serpro.caixa.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class InfoTrabalhadores {

	private String cpf;
	private String matricula;
	private String categoria;
	private String inicioTSVE;
	private String vinculo;
	private String alteracao;
	private List<Depositos> depositos;
	
	public InfoTrabalhadores() {
		this.depositos = new ArrayList<>();
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getInicioTSVE() {
		return inicioTSVE;
	}

	public void setInicioTSVE(String inicioTSVE) {
		this.inicioTSVE = inicioTSVE;
	}

	public String getVinculo() {
		return vinculo;
	}

	public void setVinculo(String vinculo) {
		this.vinculo = vinculo;
	}

	public String getAlteracao() {
		return alteracao;
	}

	public void setAlteracao(String alteracao) {
		this.alteracao = alteracao;
	}

	public List<Depositos> getDepositos() {
		return depositos;
	}

	public void setDepositos(List<Depositos> depositos) {
		this.depositos = depositos;
	}

		
}
