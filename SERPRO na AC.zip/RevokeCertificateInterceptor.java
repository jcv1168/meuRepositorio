package br.gov.caixa.icp.channel.interceptor;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.cert.CRLException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509CRLEntry;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import br.gov.caixa.icp.aclib.DNFieldExtractor;
import br.gov.caixa.icp.ar.console.auth.AuthenticationHelper;
import br.gov.caixa.icp.ar.helper.CertificateHelper;
import br.gov.caixa.icp.ar.log.negocio.LogSeguroManager;
import br.gov.caixa.icp.ar.model.Configuracao;
import br.gov.caixa.icp.ar.model.LogEntry;
import br.gov.caixa.icp.ar.model.Servidor;
import br.gov.caixa.icp.ar.model.dao.ConfiguracaoDao;
import br.gov.caixa.icp.ar.model.dao.ServidoresDao;
import br.gov.caixa.icp.ar.model.dao.SituacaoSolicitacaoDao;
import br.gov.caixa.icp.ar.model.dao.SolicitacaoDao;
import br.gov.caixa.icp.ar.util.RemoteID;
import br.gov.caixa.icp.channel.CAChannelException;
import br.gov.caixa.icp.channel.CAChannelFactory;
import br.gov.caixa.icp.channel.ICAChannel;
import br.gov.caixa.icp.channel.NoSuchCAChannelType;
import br.gov.caixa.icp.channel.dto.CAInfoDTO;
import br.gov.caixa.icp.ws.CEFACException;


/**
 * Interceptor que verifica a CRL dos Certificados
 *
 * @author JCV
 */
public class RevokeCertificateInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = Logger.getLogger(RevokeCertificateInterceptor.class);

	private  ConfiguracaoDao dao;
	private String errorPage;
	private String porta;
	/** Auxiliar para a validacao de certificados */
	private AuthenticationHelper helper;
	private LogSeguroManager logSeguroManager;
	private CertificateHelper certHelper = new CertificateHelper();
	private LogEntry logEntry;
	private String theInfo;
	

	/** Acesso a dados para {@link Configuracao} */
	private ServidoresDao servidoresDao;
	
	@Override
	public boolean preHandle(HttpServletRequest request,HttpServletResponse response, Object handler) throws IOException, ServletException {
		logger.info("iniciando interceptor CRL");
		logger.info("obtendo Certificado");
		
		
		//Localiza o registro do servidor no banco de dados
		Servidor server = servidoresDao.findByPk(request.getServerName());
		if (server != null) {
			porta = server.getPortaSSL2();
		}
		X509Certificate cert = (X509Certificate) request.getSession().getAttribute("userCertificate");

		if (cert==null) {
			logger.debug("session is null");
			if (helper!=null) {
				logger.debug("helper is NOT null");
				cert = helper.getCertificate();
			}
			if (cert==null) {
				logger.debug("Certificate is null");
				return true;
			}
		}

		
		/*Log Evento*/
		logger.debug("===>Seta propriedades do LogEntry");
		logEntry.setAuditState(LogEntry.AUDIT_LOGGED);
		logEntry.setModulo(LogEntry.MODULO_CONSULTA_LCR);
		logEntry.setIp(RemoteID.getRemoteInfo(request));
		logEntry.setCertificadoAdm(cert.getSubjectX500Principal().getName());
		logEntry.setCodigoEvento(LogEntry.CONSULTA_LCR);
		logEntry.setNumeroSequencial(request.getLocalAddr());
		logEntry.setSeveridade(LogEntry.SEVERITY_EVENT);
		logEntry.setDescricao("Certificado nao esta revogado, acesso ao modulo " + theInfo + " liberado");
		logger.debug("===> Fim Seta propriedades do LogEntry");
		/*Fim Log Evento*/
		
		
		logger.debug("obtendo Certificado");
		logger.debug("===================");
		logger.debug("Serial Number  : " + cert.getSerialNumber());
		logger.debug("Issuer		 : " + cert.getIssuerDN());
		logger.debug("Subject		 : " + cert.getSubjectDN());
		
		logger.debug("Esta Revogado?");
		logger.info("buscando o endereco da AC mestre");
		
		// CEFARV2 - multiplas AC
		// Moises Dutra - 11/05/2011
		String enderecoAc = "";
		String issuerV2ID = dao.findByPk(Configuracao.ISSUERV2ID).getValor();
		Integer channelType;		
		
		//retirada a referencia da v1 - Choco 14/06/2016 - v5
		//if (cert.getIssuerDN().toString().matches(issuerV2ID.toLowerCase()) || cert.getIssuerDN().toString().matches(issuerV2ID.toUpperCase())) {
			enderecoAc = dao.findByPk(Configuracao.LINK_WSV2).getValor();
		//	channelType = CAChannelFactory.CACHANNEL_TYPE_WS_V2;
		//} else {
		//	enderecoAc = dao.findByPk(Configuracao.LINK_WS).getValor();
		//	channelType = CAChannelFactory.CACHANNEL_TYPE_WS_V1;
		//}		
		
		if (cert.getIssuerDN().toString().matches(issuerV2ID.toLowerCase()) || cert.getIssuerDN().toString().matches(issuerV2ID.toUpperCase())) {
			channelType = CAChannelFactory.CACHANNEL_TYPE_WS_V2;
		}else {
			channelType = CAChannelFactory.CACHANNEL_TYPE_WS_V5;
		}
		
		String errorUrl = "https://"+ request.getServerName() + ":"	+ porta + errorPage;
		logger.info("obtendo o username");
		ICAChannel channel;
		boolean revoked=true;
		
		try {
			logger.info("Calling Channel");
			channel = CAChannelFactory.getCAChannel(channelType);
			channel.setConnectionString(enderecoAc);
			
			logger.info("return Channel");
			DNFieldExtractor dnfe = new DNFieldExtractor(cert.getSubjectX500Principal().getName(),DNFieldExtractor.TYPE_SUBJECTDN);
			String ou = dnfe.getField(dnfe.OU, 1);
			logger.debug("AC do Subject : " + ou);
			logger.debug("Perguntando a AC no Interceptor");
			
			/*
			 * [JAD] 10/03/2020 - Rotina para verificar OID serpro e dominio caixa na upn e no rfc822name
			 * ACCAIXA
			 * se(!serpro) 
			 * 		[vai pro revoked abaixo] 
			 * senao 
			 * 		[vou consultar iscaixa 
			 * 				(ver os 2 oid e ver se tem caixa.gov.br no RFC822Name)]
			 */
			
			boolean oidserpro = certHelper.isOIDSerpro(cert);
			boolean caixa = certHelper.isCaixa(cert);
			if(!oidserpro) {
				revoked = channel.isRevoked(cert.getIssuerDN().getName(), cert.getSerialNumber().toByteArray());
			} else {
				if(caixa) {
					revoked = false;
				}
			}
				
			logger.debug("Resposta da AC ao Interceptor : " + revoked);
			
			if (revoked) {
				String revokeDate = channel.getRevokeDate(cert.getIssuerDN().getName(), cert.getSerialNumber().toByteArray());
				logger.debug("revokeDate : " + revokeDate);
				logEntry.setDescricao("Certificado esta revogado, acesso ao modulo " + theInfo + " bloqueado");
				logSeguroManager.logEventoITI(logEntry);
				//request.getSession().invalidate();
				logger.debug("Error Url : " + errorUrl);
				//response.sendRedirect(errorUrl);
				
				request.getSession().invalidate();
				request.getSession().setAttribute("theDate", revokeDate);
				request.getRequestDispatcher(errorPage).forward(request, response);
				return false;
			}
			
		} catch (NoSuchCAChannelType nsce) {
			// TODO Auto-generated catch block
			/*Log Excecao*/
			logEntry.setSeveridade(LogEntry.SEVERITY_ERROR);
			logEntry.setDescricao("Falha na configuracao do Channel");
			logSeguroManager.logExcecaoITI(logEntry,nsce);
			/*Fim Log Excecao*/
			logger.error("Falha na configuracao do Channel", nsce);
			
			request.getSession().invalidate();
			request.getSession().setAttribute("errormessage", nsce.getMessage());
			request.getRequestDispatcher(errorPage).forward(request, response);
			return false;
		} catch (CAChannelException cce) {
			// TODO Auto-generated catch block
			/*Log Excecao*/
			logEntry.setSeveridade(LogEntry.SEVERITY_ERROR);
			logEntry.setDescricao("Erro no Processamento da Requisicao");
			logSeguroManager.logExcecaoITI(logEntry,cce);
			/*Fim Log Excecao*/
			logger.error("Erro no Processamento da Requisicao", cce);
			
			request.getSession().invalidate();
			request.getSession().setAttribute("errormessage", cce.getMessage());
			request.getRequestDispatcher(errorPage).forward(request, response);	
			return false;
		} catch (IOException ioe) {
			// TODO Auto-generated catch block
			/*Log Excecao*/
			logEntry.setSeveridade(LogEntry.SEVERITY_ERROR);
			logEntry.setDescricao("Erro na consulta de LCR");
			logSeguroManager.logExcecaoITI(logEntry,ioe);
			/*Fim Log Excecao*/		
			logger.error("Erro na consulta de LCR", ioe);
			
			request.getSession().invalidate();
			request.getSession().setAttribute("errormessage", ioe.getMessage());
			request.getRequestDispatcher(errorPage).forward(request, response);		
			return false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			/*Log Excecao*/
			logEntry.setSeveridade(LogEntry.SEVERITY_ERROR);
			logEntry.setDescricao("Erro Geno WebService");
			logSeguroManager.logExcecaoITI(logEntry,e);
			/*Fim Log Excecao*/		
			logger.error("Erro na consulta de LCR", e);
			
			request.getSession().invalidate();
			request.getSession().setAttribute("errormessage", e.getMessage());
			request.getRequestDispatcher(errorPage).forward(request, response);		
			return false;
		}
		
		return true;

	}
	
	
	public LogEntry getLogEntry() {
		return logEntry;
	}

	public void setLogEntry(LogEntry logEntry) {
		this.logEntry = logEntry;
	}

	public String getTheInfo() {
		return theInfo;
	}

	public void setTheInfo(String theInfo) {
		this.theInfo = theInfo;
	}

	// getters e setters
	public void setDao(ConfiguracaoDao dao) {
		this.dao = dao;
	}
	
	public ConfiguracaoDao getDao() {
		return dao;
	}
	public void setErrorPage(String errorpage) {
		errorPage = errorpage;
	}
	
	public String getErrorPage() {
		return errorPage;
	}
	
	public AuthenticationHelper getHelper() {
		return helper;
	}

	public void setHelper(AuthenticationHelper helper) {
		this.helper = helper;
	}

	public LogSeguroManager getLogSeguroManager() {
		return logSeguroManager;
	}

	public void setLogSeguroManager(LogSeguroManager logSeguroManager) {
		this.logSeguroManager = logSeguroManager;
	}
	
	public ServidoresDao getServidoresDao() {
		return servidoresDao;
	}

	public void setServidoresDao(ServidoresDao servidoresDao) {
		this.servidoresDao = servidoresDao;
	}		
	

	
}
