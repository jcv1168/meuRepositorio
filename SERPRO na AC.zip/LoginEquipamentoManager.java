package br.gov.caixa.icp.ar.console.auth;

import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

import br.gov.caixa.icp.ar.helper.CertificateHelper;
import br.gov.caixa.icp.ar.log.negocio.LogSeguroManager;
import br.gov.caixa.icp.ar.model.Configuracao;
import br.gov.caixa.icp.ar.model.ControleAcesso;
import br.gov.caixa.icp.ar.model.Equipamento;
import br.gov.caixa.icp.ar.model.Grupo;
import br.gov.caixa.icp.ar.model.LogEntry;
import br.gov.caixa.icp.ar.model.NumeracaoAuditoria;
import br.gov.caixa.icp.ar.model.Papel;
import br.gov.caixa.icp.ar.model.Unidade;
import br.gov.caixa.icp.ar.model.Usuario;
import br.gov.caixa.icp.ar.model.dao.ConfiguracaoDao;
import br.gov.caixa.icp.ar.model.dao.ControleAcessoDao;
import br.gov.caixa.icp.ar.model.dao.EquipamentoDao;
import br.gov.caixa.icp.ar.model.dao.NumeracaoAuditoriaDao;
import br.gov.caixa.icp.ar.model.dao.UnidadeDao;
import br.gov.caixa.icp.ar.util.RemoteID;

/**
 * Manager responsavel por verificar se um determinado usuario esta efetuando
 * login a partir de uma maquina cadastrada.
 *
 * @author FSW
 * @version 1.0 - 20/04/2007 - Alan P: implementacao <br>
 * @version 1.1 - 23/09/2009 - Moises Dutra: Login/Logoff <br>
 * @version 1.2 - 16/03/2010 - Moises Dutra: inclusao do activePaper <br>
 *
 * @see Equipamento
 * @see Unidade
 * @see Usuario
 */
public class LoginEquipamentoManager {

	private static Pattern pattern;
    private static Matcher matcher;
 
    private static final String IPADDRESS_PATTERN = 
		"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		"([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
	
	
	/** Logger */
	private static final Logger logger = Logger.getLogger(LoginEquipamentoManager.class);

	/** Auxiliar de autenticacao */
	private AuthenticationHelper authHelper;

	/** Acesso a dados para {@link Equipamento} */
	private EquipamentoDao equipamentoDao;

	/** Acesso a dados para {@link ControleAcesso} */
	private ControleAcessoDao controleDao;

	/** Acesso a dados para {@link Numeracao Auditoria} */
	private NumeracaoAuditoriaDao numeracaoDao;
	
	/** Acesso a dados para {@link Unidade} */
	private UnidadeDao unidadeDao;
	
	public static final int REASON_OK=0;
	public static final int REASON_PROFILE=1;
	public static final int REASON_MACHINE=2;
	public static final int REASON_USER_NOT_FOUND=3;
	public static final int REASON_UNIT=4;
	public static final int REASON_MISMATCH=5;
	public static final int REASON_EXCEPTION=6;
	public static final int REASON_NO_CERTIFICATE=7;
	public static final int REASON_SESSION_NULL=8;
	public static final int REASON_WRONG_HOSTNAME=9;
	public static final int REASON_USER_INATIVE=10;
	
	private LogSeguroManager logSeguroManager;
	private LogEntry logEntry;
	private String theInfo;
	private String activePaper;
	private boolean userIsNull=false;
	private boolean isNotPFA3=false;
	private int reasonCode=0;
	private String message="Erro interno";

	/**
	 * Verifica se um determinado ip tem acesso permitido ao sistema. <br>
	 * Primeiramente o {@link Equipamento} correspondente a esse IP sera buscado
	 * na base de dados. Em seguida sera verificado se o {@link Grupo} do
	 * {@link Usuario} autenticado contem algum {@link Papel} que exista no
	 * {@link Grupo} a que pertence a {@link Unidade} do {@link Equipamento}
	 * encontrado.
	 *
	 * @param ip
	 *            IP.
	 * @return true se o acesso for permitido.
	 *
	 * @see AuthenticationHelper#getPrincipal()
	 */
	public boolean permiteAcesso(String ip, String local, String ar) {
		
		pattern = Pattern.compile(IPADDRESS_PATTERN);
		
		
		if (ip==null || local==null) {
			logger.error("Erro Sessao Nula (ip)");
			reasonCode=REASON_SESSION_NULL;
			return false;
		}
		
		boolean perfil = false;
		logger.info("verificando permissao de acesso");
		logger.debug(ip + "/" + theInfo);
		CertificateHelper certHelper = new CertificateHelper();
		X509Certificate x509 = authHelper.getCertificate();
		
		if (x509==null) {
			logger.error("Erro Sessao Nula (certificado)");
			reasonCode=REASON_NO_CERTIFICATE;
			return false;
		}
		
		if (!certHelper.validaCaixaPFA3(x509)) {
			isNotPFA3=true;
			/*Log Evento*/
			logger.debug("===>Seta propriedades do LogEntry");
			logEntry.setAuditState(LogEntry.AUDIT_LOGGED);
			logEntry.setModulo(LogEntry.MODULO_CONTROLE_ACESSO);
			logEntry.setIp(ip);
			if (x509!=null) {
				logger.error("x509 is not null");
				logEntry.setCertificadoAdm(authHelper.getPrincipal().getSubjectDn());
			} else {
				logger.error("x509 is null");
			}
			logEntry.setCertificadoAlvo("NAO SE APLICA");
			logEntry.setCodigoEvento(LogEntry.LOGIN_EQUIPAMENTO_NEGADO);
			logEntry.setNumeroSequencial(local);
			logEntry.setSeveridade(LogEntry.SEVERITY_EVENT);
			logEntry.setDescricao("Login do Equipamento " + ip + " ao Modulo " + theInfo + " negado. (Certificado nao e PFA3)");
			logger.debug("===> Fim Seta propriedades do LogEntry");
			logSeguroManager.logEventoITI(logEntry);
			/*Fim Log Evento*/		
			return false;
		}
		
		try {
			logger.info("dados do usuario autenticado");
			Usuario usuario = authHelper.getPrincipal();
			
			//Demanda para verificar usuario ativo ao acessar Validacao e Verificacao - Moises Dutra - 26/08/2011
			if (usuario.isAtivo() == false) {
				reasonCode=REASON_USER_INATIVE;
				return false;
			}
			
			if (usuario==null) {
				userIsNull=true;				
	
				/*Log Evento*/
				logger.debug("===>Seta propriedades do LogEntry");
				logEntry.setAuditState(LogEntry.AUDIT_LOGGED);
				logEntry.setModulo(LogEntry.MODULO_CONTROLE_ACESSO);
				logEntry.setIp(ip);
				if (x509!=null) {
					logger.error("x509 is not null");
					logEntry.setCertificadoAdm(authHelper.getPrincipal().getSubjectDn());
				} else {
					logger.error("x509 is null");
				}
				logEntry.setCertificadoAlvo("NAO SE APLICA");
				logEntry.setCodigoEvento(LogEntry.LOGIN_EQUIPAMENTO_NEGADO);
				logEntry.setNumeroSequencial(local);
				logEntry.setSeveridade(LogEntry.SEVERITY_EVENT);
				logEntry.setDescricao("Login do Equipamento " + ip + " ao Modulo " + theInfo + " negado. (Usuario nao Cadastrado)");
				logger.debug("===> Fim Seta propriedades do LogEntry");
				logSeguroManager.logEventoITI(logEntry);
				/*Fim Log Evento*/		
				return false;
			}
			logger.info("grupo do usuario autenticado");
			Grupo grupoUsuario = usuario.getGrupo();
			Collection<Papel> papeisUsuario = grupoUsuario.getPapeis();

			logger.info("dados do equipamento autenticado");
			logger.info("buscando ip " + ip + " na base");
			
			Collection<Equipamento> equips = null;
			
			//caso n�o seja Console AR testa IP
			if (!theInfo.equals("Console AR")) {
				if (RemoteID.allowHostName) {
					equips = equipamentoDao.findByMask(ip);
				} else {
					equips = equipamentoDao.findByIp(ip);
				}			
				
				if ((equips.size() == 0) && (ar==null)) {
					logger.warn("nenhum equipamento com este ip " + ip + " esta cadastrado," + " negando acesso");
					/*Log Evento*/
					logger.debug("===>Seta propriedades do LogEntry");
					logEntry.setAuditState(LogEntry.AUDIT_LOGGED);
					logEntry.setModulo(LogEntry.MODULO_CONTROLE_ACESSO);
					logEntry.setIp(ip);
					logEntry.setCertificadoAdm(authHelper.getPrincipal().getSubjectDn());
					logEntry.setCertificadoAlvo("NAO SE APLICA");
					logEntry.setCodigoEvento(LogEntry.LOGIN_EQUIPAMENTO_NEGADO);
					logEntry.setNumeroSequencial(local);
					logEntry.setSeveridade(LogEntry.SEVERITY_EVENT);
					logEntry.setDescricao("Login do Equipamento " + ip + " ao Modulo " + theInfo + " negado. (Equipamento nao Cadastrado)");
					logger.debug("===> Fim Seta propriedades do LogEntry");
					logSeguroManager.logEventoITI(logEntry);
					matcher = pattern.matcher(ip);
					if (RemoteID.allowHostName && matcher.matches()) {
						reasonCode = REASON_WRONG_HOSTNAME;
					} else {
						reasonCode = REASON_MACHINE;
					}
					/*Fim Log Evento*/		
					//logSeguroManager.logEvento(authHelper.getPrincipal(),Priority.INFO, "Login Equipamento", "Acesso negado");
					
	
					return false;
				}
			}
			
			//Testa o papel
			if (theInfo.equals("Console AR") && (papeisUsuario.contains(Papel.ADMIN) || papeisUsuario.contains(Papel.GERENTE))) {
				logger.info("usuario administrador ou gerente, permitindo acesso");			

				//Registra o login de acesso no banco de dados
				if ((numeracaoDao != null ) && (controleDao != null)) {				
					ControleAcesso controle = new ControleAcesso();	

					String servidor = local;
					NumeracaoAuditoria example = new NumeracaoAuditoria();
					example.setServidor(servidor);
					List retorno = numeracaoDao.findByExample(example);
					NumeracaoAuditoria numeracao = (NumeracaoAuditoria) retorno.get(0);

					Integer nu_acesso = Integer.valueOf(numeracao.getSequencialLogin()) + 1;
					numeracao.setSequencialLogin(nu_acesso);
					numeracaoDao.merge(numeracao);

					controle.setNumero(nu_acesso);
					controle.setDescricao(usuario.getSubjectDn());
					controle.setInicioAcesso(new Date());
					controle.setEndereco(ip);

					ControleAcesso merged = controleDao.merge(controle);
					logger.debug(merged);
				}


				/*Log Evento*/
				logger.debug("===>Seta propriedades do LogEntry");
				logEntry.setAuditState(LogEntry.AUDIT_LOGGED);
				logEntry.setModulo(LogEntry.MODULO_CONTROLE_ACESSO);
				logEntry.setIp(ip);
				logEntry.setCertificadoAdm(authHelper.getPrincipal().getSubjectDn());
				logEntry.setCodigoEvento(LogEntry.LOGIN_EQUIPAMENTO);
				logEntry.setNumeroSequencial(local);
				logEntry.setSeveridade(LogEntry.SEVERITY_EVENT);
				logEntry.setDescricao("Login do Equipamento " + ip + " ao Modulo " + theInfo + " permitido");
				logger.debug("===> Fim Seta propriedades do LogEntry");
				logSeguroManager.logEventoITI(logEntry);
				reasonCode=REASON_PROFILE;
				return true;
			} 

			if (theInfo.equals("Validacao") && papeisUsuario.contains(Papel.VALIDADOR)) {
				logger.info("usuario Validador, permitindo acesso: " + Papel.VALIDADOR);
				logger.info("PapeisUsuario: " + papeisUsuario);
				perfil=true;
			}

			if (theInfo.equals("Verificacao") && papeisUsuario.contains(Papel.VERIFICADOR)) {
				logger.info("usuario Verificador, permitindo acesso: " + Papel.VERIFICADOR);
				logger.info("PapeisUsuario: " + papeisUsuario);
				perfil=true;
			}

			if (!perfil) {
				/*Log Evento*/
				if (usuario.getNome().equals("NO AUTHORIZED USER")) {
					logger.debug("User is null");
					userIsNull=true;
				}
				logger.debug("===>Seta propriedades do LogEntry");
				logEntry.setAuditState(LogEntry.AUDIT_LOGGED);
				logEntry.setModulo(LogEntry.MODULO_CONTROLE_ACESSO);
				logEntry.setIp(ip);
				logEntry.setCertificadoAdm(authHelper.getPrincipal().getSubjectDn());
				logEntry.setCertificadoAlvo("NAO SE APLICA");
				logEntry.setCodigoEvento(LogEntry.LOGIN_EQUIPAMENTO_NEGADO);
				logEntry.setNumeroSequencial(local);
				logEntry.setSeveridade(LogEntry.SEVERITY_EVENT);
				logEntry.setDescricao("Login do Equipamento " + ip + " ao Modulo " + theInfo + " negado. (Perfil Invalido)");
				logger.debug("===> Fim Seta propriedades do LogEntry");
				logSeguroManager.logEventoITI(logEntry);
				reasonCode=REASON_PROFILE;
				/*Fim Log Evento*/
				
				reasonCode=REASON_PROFILE;
				return false;
			}

			Unidade unidade=null;
			logger.info("obtendo dados da unidade");
			if (ar!=null) {
				logger.debug("param : " + ar);
				Unidade exemplo = new Unidade();
				exemplo.setCentroCusto(ar);
				List<Unidade> l = unidadeDao.findByExample(exemplo);
				if (!l.isEmpty()) {
					unidade = l.get(0);
					logger.debug("perfil unidade : " + unidade.getPerfilCertificacao());
				}
			} else {
				unidade = authHelper.getUnidadePrincipal(ip);				
			}
			//caso n�o seja Console AR testa IP
			if (unidade == null && !theInfo.equals("Console AR")) {
				logger.info("equipamento nao esta associado a nenhuma unidade");
				/*Log Evento*/
				logger.debug("===>Seta propriedades do LogEntry");
				logEntry.setAuditState(LogEntry.AUDIT_LOGGED);
				logEntry.setModulo(LogEntry.MODULO_CONTROLE_ACESSO);
				logEntry.setIp(ip);
				logEntry.setCertificadoAdm(authHelper.getPrincipal().getSubjectDn());
				logEntry.setCodigoEvento(LogEntry.LOGIN_EQUIPAMENTO_NEGADO);
				logEntry.setNumeroSequencial(local);
				logEntry.setSeveridade(LogEntry.SEVERITY_EVENT);
				logEntry.setDescricao("Login do Equipamento " + ip + " ao Modulo " + theInfo + " negado. (Ip nao pertence a nenhuma Unidade)");
				logger.debug("===> Fim Seta propriedades do LogEntry");
				logSeguroManager.logEventoITI(logEntry);
				matcher = pattern.matcher(ip);
				if (RemoteID.allowHostName && matcher.matches()) {
					reasonCode = REASON_WRONG_HOSTNAME;
				} else {
					reasonCode = REASON_MACHINE;
				}
				/*Fim Log Evento*/		
				//logSeguroManager.logEvento(authHelper.getPrincipal(),Priority.INFO, "Login Equipamento", "Acesso negado");
				return false;
			}

			Grupo grupo = unidade.getGrupo();
			if (grupo == null && !theInfo.equals("Console AR")) {
				logger.info("unidade nao possui grupo, negar acesso");
				/*Log Evento*/
				logger.debug("===>Seta propriedades do LogEntry");
				logEntry.setAuditState(LogEntry.AUDIT_LOGGED);
				logEntry.setModulo(LogEntry.MODULO_CONTROLE_ACESSO);
				logEntry.setIp(ip);
				logEntry.setCertificadoAdm(authHelper.getPrincipal().getSubjectDn());
				logEntry.setCodigoEvento(LogEntry.LOGIN_EQUIPAMENTO_NEGADO);
				logEntry.setNumeroSequencial(local);
				logEntry.setSeveridade(LogEntry.SEVERITY_EVENT);
				logEntry.setDescricao("Login do Equipamento " + ip + " ao Modulo " + theInfo + " negado. (Unidade nao possui permissao adequada)");
				logger.debug("===> Fim Seta propriedades do LogEntry");
				logSeguroManager.logEventoITI(logEntry);
				reasonCode=REASON_UNIT;
				/*Fim Log Evento*/
				//logSeguroManager.logEvento(authHelper.getPrincipal(),Priority.INFO, "Login Equipamento", "Acesso negado");
				return false;
			}

			logger.info("verificando papeis da unidade");
			Collection<Papel> papeisUnidade = grupo.getPapeis();
			for (Papel pUsuario : papeisUsuario) {
				for (Papel pUnidade : papeisUnidade) {					
					if (pUsuario.equals(pUnidade)) {
						// Avalia se o papel da unidade esta relacionado ao papel em uso do usuario - Moises Dutra - 16/03/2010
						if (pUsuario.getNome().equals(activePaper)) {

							logger.info("papel em comum encontrado,"
									+ " retornando true");


							//Registra o login de acesso no banco de dados
							if ((numeracaoDao != null ) && (controleDao != null)) {				
								ControleAcesso controle = new ControleAcesso();	

								String servidor = local;
								NumeracaoAuditoria example = new NumeracaoAuditoria();
								example.setServidor(servidor);
								List retorno = numeracaoDao.findByExample(example);
								NumeracaoAuditoria numeracao = (NumeracaoAuditoria) retorno.get(0);

								Integer nu_acesso = Integer.valueOf(numeracao.getSequencialLogin()) + 1;
								numeracao.setSequencialLogin(nu_acesso);
								numeracaoDao.merge(numeracao);

								controle.setNumero(nu_acesso);
								controle.setDescricao(usuario.getSubjectDn());
								controle.setInicioAcesso(new Date());
								controle.setEndereco(ip);

								ControleAcesso merged = controleDao.merge(controle);
								logger.debug(merged);
							}

							/*Log Evento*/
							logger.debug("===>Seta propriedades do LogEntry");
							logEntry.setAuditState(LogEntry.AUDIT_LOGGED);
							logEntry.setModulo(LogEntry.MODULO_CONTROLE_ACESSO);
							logEntry.setIp(ip);
							logEntry.setCertificadoAdm(authHelper.getPrincipal().getSubjectDn());
							logEntry.setCodigoEvento(LogEntry.LOGIN_EQUIPAMENTO);
							logEntry.setNumeroSequencial(local);
							logEntry.setSeveridade(LogEntry.SEVERITY_EVENT);
							logEntry.setDescricao("Login do Equipamento " + ip + " ao Modulo " + theInfo + " permitido");
							logger.debug("===> Fim Seta propriedades do LogEntry");
							logSeguroManager.logEventoITI(logEntry);
							/*Fim Log Evento*/			
							//logSeguroManager.logEvento(authHelper.getPrincipal(),Priority.INFO, "Login Equipamento","Acesso permitido");
							return true;
						}
					}
				}
			}


		} catch (RuntimeException re) {
			logger.error("erro no processamento da permissao de acesso", re);	
			/*Log Evento*/
			logger.debug("===>Seta propriedades do LogEntry");
			logEntry.setAuditState(LogEntry.AUDIT_LOGGED);
			logEntry.setModulo(LogEntry.MODULO_CONTROLE_ACESSO);
			logEntry.setIp(ip);
			logEntry.setCertificadoAdm(authHelper.getPrincipal().getSubjectDn());
			logEntry.setCodigoEvento(LogEntry.LOGIN_EQUIPAMENTO);
			logEntry.setNumeroSequencial(local);
			logEntry.setSeveridade(LogEntry.SEVERITY_ERROR);
			logEntry.setDescricao("Ocorreu um erro no Login do Equipamento " + ip + " ao Modulo " + theInfo);
			logger.debug("===> Fim Seta propriedades do LogEntry");
			logSeguroManager.logExcecaoITI(logEntry, re);
			logSeguroManager.logEventoITI(logEntry);
			message=re.getMessage();
			reasonCode=REASON_EXCEPTION;
			return false;
			/*Fim Log Evento*/
			//logSeguroManager.logExcecao(authHelper.getPrincipal(),Priority.ERROR, "Login Equipamento","Erro no login de equipamento", re);
		}


		logger.info("acesso negado, retornando");
		//logSeguroManager.logEvento(authHelper.getPrincipal(), Priority.INFO,"Login Equipamento", "Acesso negado");
		/*Log Evento*/
		logger.debug("===>Seta propriedades do LogEntry");
		logEntry.setAuditState(LogEntry.AUDIT_LOGGED);
		logEntry.setModulo(LogEntry.MODULO_CONTROLE_ACESSO);
		logEntry.setIp(ip);
		logEntry.setCertificadoAdm(authHelper.getPrincipal().getSubjectDn());
		logEntry.setCodigoEvento(LogEntry.LOGIN_EQUIPAMENTO_NEGADO);
		logEntry.setNumeroSequencial(local);
		logEntry.setSeveridade(LogEntry.SEVERITY_EVENT);
		logEntry.setDescricao("Login do Equipamento " + ip + " ao Modulo " + theInfo + " negado. (Unidade e Operador nao possuem o mesmo perfil)");
		logger.debug("===> Fim Seta propriedades do LogEntry");
		logSeguroManager.logEventoITI(logEntry);
		/*Fim Log Evento*/
		reasonCode=REASON_MISMATCH;
		return false;
	}

	// getters e setters

	public boolean isNotPFA3() {
		return isNotPFA3;
	}


	public AuthenticationHelper getAuthHelper() {
		return authHelper;
	}

	public void setAuthHelper(AuthenticationHelper authHelper) {
		this.authHelper = authHelper;
	}

	public EquipamentoDao getEquipamentoDao() {
		return equipamentoDao;
	}

	public void setEquipamentoDao(EquipamentoDao equipamentoDao) {
		this.equipamentoDao = equipamentoDao;
	}

	public ControleAcessoDao getControleDao() {
		return controleDao;
	}

	public void setControleDao(ControleAcessoDao controleDao) {
		this.controleDao = controleDao;
	}

	public NumeracaoAuditoriaDao getNumeracaoDao() {
		return numeracaoDao;
	}

	public void setNumeracaoDao(NumeracaoAuditoriaDao numeracaoDao) {
		this.numeracaoDao = numeracaoDao;
	}

	public LogSeguroManager getLogSeguroManager() {
		return logSeguroManager;
	}

	public void setLogSeguroManager(LogSeguroManager logSeguroManager) {
		this.logSeguroManager = logSeguroManager;
	}

	public LogEntry getLogEntry() {
		return logEntry;
	}

	public void setLogEntry(LogEntry logEntry) {
		this.logEntry = logEntry;
	}

	public String getTheInfo() {
		return theInfo;
	}

	public void setActivePaper(String activePaper) {
		this.activePaper = activePaper;
	}

	public String getActivePaper() {
		return activePaper;
	}

	public void setTheInfo(String theInfo) {
		this.theInfo = theInfo;
	}	

	public boolean isUserIsNull() {
		return userIsNull;
	}
	
	public String getMessage() {
		return message;
	}

	public int getReasonCode() {
		return reasonCode;
	}
	
	public UnidadeDao getUnidadeDao() {
		return unidadeDao;
	}

	public void setUnidadeDao(UnidadeDao unidadeDao) {
		this.unidadeDao = unidadeDao;
	}


}
