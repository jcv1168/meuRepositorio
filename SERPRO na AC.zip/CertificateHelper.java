package br.gov.caixa.icp.ar.helper;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERString;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.PolicyInformation;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.springframework.web.multipart.MultipartFile;

/**
 * Helper para obtencao de certificados
 *
 * @author FSW
 * @version 1.0 - 08/03/2007 - Alan P: implementacao <br>
 *          1.1 - 22/08/2007 - Willian Oki: validaCaixaA3() <br>
 *          1.2 - 13/09/2007 - Alan P: hash SHA-1 de certificado <br>
 *
 */
public class CertificateHelper {

	/** Logger */
	private static final Logger logger = Logger.getLogger(CertificateHelper.class);

	/** Certificate Factory para parsing de certificados */
	private static CertificateFactory x509Factory;

	// inicializacao da certificateFactory
	static {
		try {
			logger.info("inicializando X509 factory");
			x509Factory = CertificateFactory.getInstance("X.509");
			logger.info("inicializacao ok (x509Factory)");
		} catch (CertificateException ce) {
			logger.error("Erro obtendo a certificate factory para X.509", ce);
		}
	}

	/**
	 * Obtem o certificado do cliente.
	 *
	 * @param request
	 *            {@link HttpServletRequest}.
	 * @return Certificado do cliente ou null.
	 */
	public X509Certificate getCertificate(HttpServletRequest request) {
		X509Certificate certificate = (X509Certificate) request.getAttribute("javax.servlet.request.X509Certificate");
		if (certificate == null) {
			certificate = (X509Certificate) request.getSession().getAttribute("javax.servlet.request.X509Certificate");
		}
		return certificate;
	}

	/**
	 * Obtem o hash MD5 de um certificado.
	 *
	 * @param cert
	 *            bytes do certificado.
	 * @return Hash MD5.
	 */
	public String getCertificateMD5(byte[] cert) {
		return getCertificateMD5(getX509(cert));
	}

	/**
	 * Obtem o hash MD5 de um certificado X509.
	 *
	 * @param cert
	 *            X509Certificate.
	 * @return String contendo o hash do certificado ou null em caso de erros.
	 */
	public String getCertificateMD5(X509Certificate cert) {
		logger.info("inicializando criacao de hash de certificado");
		if (logger.isDebugEnabled()) {
			logger.debug(cert);
		}
		try {
			logger.info("obtendo digest");
			
			String id = Integer.toString(cert.getSerialNumber().intValue());
			
			MessageDigest md = MessageDigest.getInstance("MD5");

			logger.info("gerando hash");
			byte[] hashBytes = md.digest(id.getBytes());
			//byte[] hashBytes = md.digest(cert.getEncoded());

			logger.info("transformando em string (hexa)");
			BigInteger hash = new BigInteger(1, hashBytes);
			String hashHexa = hash.toString(16);

			logger.info("finalizado, retornando");
			logger.debug(hashHexa);
			return hashHexa;
			
		//} catch (CertificateEncodingException cee) {
		//	logger.error("erro obtendo certificado encoded", cee);
		} catch (NoSuchAlgorithmException nsae) {
			logger.error("erro obtendo digest md5", nsae);
		}
		return null;
	}

	/**
	 * Obtem o hash SHA-1 de um certificado X509.
	 *
	 * @param cert
	 *            X509Certificate.
	 * @return String contendo o hash do certificado ou null em caso de erros.
	 */
	public String getCertificateSHA1(X509Certificate cert) {
		logger.info("inicializando criacao de hash de certificado");
		if (logger.isDebugEnabled()) {
			logger.debug(cert);
		}
		try {
			logger.info("obtendo digest");
			MessageDigest md = MessageDigest.getInstance("SHA-1");

			logger.info("gerando hash");
			byte[] hashBytes = md.digest(cert.getEncoded());

			logger.info("transformando em string (hexa)");
			BigInteger hash = new BigInteger(1, hashBytes);
			String hashHexa = hash.toString(16);
			
			if (hashHexa.length() < 40) {
				String padding = "0000000000000000000000000000000000000000";
				hashHexa = padding.substring(0, 40-hashHexa.length()) + hashHexa;
				
			}

			logger.info("finalizado, retornando");
			logger.debug(hashHexa);
			return hashHexa;
		} catch (CertificateEncodingException cee) {
			logger.error("erro obtendo certificado encoded", cee);
		} catch (NoSuchAlgorithmException nsae) {
			logger.error("erro obtendo digest md5", nsae);
		}
		return null;
	}

	/**
	 * Extrai um certificado contido em um array de bytes.
	 *
	 * @param cert
	 *            Bytes do certificado.
	 * @return Certificado ou null em caso de erro.
	 *
	 * @see MultipartFile
	 * @see X509Certificate
	 */
	public X509Certificate getX509(byte[] cert) {
		logger.info("obtendo um certificado a partir de um array de bytes");
		if (cert == null) {
			logger.warn("dados null, retornando");
			return null;
		}

		X509Certificate x509 = null;
		ByteArrayInputStream in = new ByteArrayInputStream(cert);
		try {
			x509 = (X509Certificate) x509Factory.generateCertificate(in);
		} catch (CertificateException ce) {
			logger.error("erro obtendo certificado", ce);
		}
		return x509;
	}

	/**
	 * Extrai um certificado X509 contido em uma {@link MultipartFile}.
	 *
	 * @param file
	 *            MultipartFile
	 * @return X509Certificate contido no arquivo ou null em caso de erros.
	 *
	 * @see #getX509(byte[])
	 */
	public X509Certificate getX509(MultipartFile file) {
		if (file == null) {
			return null;
		}

		try {
			return getX509(file.getBytes());
		} catch (IOException ioe) {
			logger.error("erro lendo os dados do arquivo");
		}
		return null;
	}

	/**
	 * Verifica se um {@link MultipartFile} contem um certificado caixa A3
	 * valido.
	 *
	 * @param file
	 *            {@link MultipartFile} contendo um certificado.
	 * @return true se o arquivo contem um certificado caixa A3 valido.
	 */
	public boolean validaCaixaA3(MultipartFile file) {
		boolean rval = false;
		X509Certificate cert = getX509(file);
		logger.debug("Valida CAIXA A3");
		if (cert != null) {
			String issuer = cert.getIssuerX500Principal().getName();
			// AC INTERNA ou AC PF:
			logger.debug("Testa Certificado de Operador : " + cert.getSubjectDN());
			if (issuer.indexOf("ADMINISTRATIVA") != -1 || issuer.indexOf("AC CAIXA PF") != -1) {
				try {
					List<PolicyInformation> policies = getPolicies(cert);
					for (PolicyInformation pi : policies) {
						if (pi.getPolicyIdentifier().getId().equals("2.16.76.1.2.3.8")) {
							rval = true;
							break;
						}
					}
				} catch (IOException e) {
					logger.error("Erro Obtendo polices do certificado " + cert.toString());
				}
			}
		}
		logger.debug("Resultado : " + rval);
		return rval;
	}

	public static DERObject decodeDERObject(byte[] bytes) throws IOException {
        ASN1InputStream dis = null;
        DERObject ret = null;

        try {
            do {
                if (bytes == null)
                    break;
                if ((dis = new ASN1InputStream(new ByteArrayInputStream(bytes))) == null)
                    break;
                ret = dis.readObject();
            } while (false);
        } finally {
            if (dis != null)
                dis.close();
        }
        return ret;
    }
	
	
	private DERObject getExtensionValue(X509Certificate cert, String oid)
			throws IOException {
		if (cert == null) {
			return null;
		}
		byte[] bytes = cert.getExtensionValue(oid);
		if (bytes == null) {
			return null;
		}
		ASN1InputStream aIn = new ASN1InputStream(new ByteArrayInputStream(bytes));
		ASN1OctetString octs = (ASN1OctetString) aIn.readObject();
		aIn = new ASN1InputStream(new ByteArrayInputStream(octs.getOctets()));
		return aIn.readObject();
	}

	public static DERObject getEncapsulatedObject(ASN1OctetString os) {
        DERObject ret = null;

        try {
            do {
                if (os == null)
                    break;
                ret = decodeDERObject(os.getOctets());
            } while (false);
        } catch (IOException ex) {
        }
        return ret;
    }
	
	public static String decodeASN1String(DERObject str) {
        if (str instanceof ASN1OctetString) {
            return new String(((ASN1OctetString) str).getOctets());
        } else if (str instanceof DERString) {
            return ((DERString) str).getString();
        } else {
            return "";
        }
    }
	
	/**
	 * [JAD] 10/03/2020
	 * Busca UPN e email do certificado verificando se ambos contem o dominio caixa: 'caixa.gov.br'
	 * @param cert
	 * @return boolean
	 */
	public boolean isCaixa(X509Certificate cert) {
		logger.info("Verificando upn e email para confirmar identidade caixa");
		final String dominio = "caixa.gov.br";
		int indexUpn = getUPNPFA3(cert).toLowerCase().indexOf(dominio);
		int indexEmail = getRfc822Name(cert).toLowerCase().indexOf(dominio);

		if((indexUpn != -1) && (indexEmail !=1)) {
			logger.info("identidade caixa confirmada!");
			return true;
		} else {
			logger.info("identidade externa. Negada!");
			return false;
		}
	}
	
	/**
	 * [JAD] 10/03/2020
	 * Busca OID do Serpro e retorna true em caso positivo
	 * @param cert
	 * @return boolean
	 */
	public boolean isOIDSerpro(X509Certificate cert) {
		logger.debug("Procurando OID do Serpro ....  " + cert.getSubjectDN());
		boolean serpro = false;
		
		if (cert != null) {
			String issuer = cert.getIssuerX500Principal().getName();
			try {
				List<PolicyInformation> policies = getPolicies(cert);
				for (PolicyInformation pi : policies) {
//						[JAD] 07/02/2020 - as Politicas de certificado (PC) implementadas pela AC SERPRO RFB sao:
//								1. PC ACSERPRORFB A3 OID 2.16.76.1.2.3.4
//								2. PC ACSERPRORFB A1 OID 2.16.76.1.2.1.10
//						e as politicas da caixa sao:
//								1. PC AC CAIXA PF - A3  OID 2.16.76.1.2.3.8
//								2. PC AC CAIXA PJ - A3  OID 2.16.76.1.2.3.9
					
					serpro = pi.getPolicyIdentifier().getId().equals("2.16.76.1.2.3.4");
					if (serpro) break;
				}
			} catch (IOException e) {
				logger.error("Erro Obtendo polices do certificado Serpro " + cert.toString());
			}
		}
		
		logger.debug("Resultado para OID serpro: " + serpro);
		return serpro;
	}
	
	/**
	 * [JAD] 10/03/2020
	 * Obtem do certificado Subject Alternative Name (RFC822Name)
	 * @param cert
	 * @return string
	 */
	public String getRfc822Name(X509Certificate cert) {
			DERObject dobj = null;
			X509CertificateStructure xcs = null;
			X509Extensions exts = null;
			X509Extension subjAltName = null;
			String strOtherName="";
			logger.info("Obtendo RFC822Name...");
			try {
				dobj = decodeDERObject(cert.getEncoded()); 
				xcs = new X509CertificateStructure((ASN1Sequence) dobj);
				exts = xcs.getTBSCertificate().getExtensions();
				subjAltName = (exts == null ? null : exts.getExtension(X509Extensions.SubjectAlternativeName));
				
				if (subjAltName != null) {
	                ASN1Sequence as = (ASN1Sequence) getEncapsulatedObject(subjAltName.getValue());
	                ASN1Sequence asName;
	                String strOID;
	                
	                for (int i = 0; i < as.size(); ++i) {
	                    GeneralName gn = GeneralName.getInstance(as.getObjectAt(i));
	                    if(gn.getTagNo() == GeneralName.rfc822Name) {
	                    	strOtherName = ((DERIA5String) gn.getName()).getString();
	                    }
	                }
	            }
	            
			} catch (CertificateEncodingException e) {
				logger.error("Erro codificando certificado");
				logger.error(e);
			} catch (IOException e) {
				logger.error("Erro I/O decodificando objeto DER.");
				logger.error(e);
			}
			return strOtherName.trim();
		}
	
	/**
	 * [JAD] 10/03/2020
	 * Obtem do certificado User o Principal Name (UPN) que 
	 * cont�m o dom�nio de login em esta��es de trabalho
	 * @param cert
	 * @return string
	 */
	public String getUPNPFA3(X509Certificate cert) {
		DERObject dobj = null;
		X509CertificateStructure xcs = null;
		X509Extensions exts = null;
		X509Extension subjAltName = null;
		Map<String, String> oids = new HashMap<String, String>();
		String matricula = "";
		logger.info("Obtendo UPN ...");
		try {
			dobj = decodeDERObject(cert.getEncoded()); 
			xcs = new X509CertificateStructure((ASN1Sequence) dobj);
			exts = xcs.getTBSCertificate().getExtensions();
			subjAltName = (exts == null ? null : exts.getExtension(X509Extensions.SubjectAlternativeName));
			
			if (subjAltName != null) {
                ASN1Sequence as = (ASN1Sequence) getEncapsulatedObject(subjAltName.getValue());
                ASN1Sequence asName;
                String strOID;
                String strOtherName;
                for (int i = 0; i < as.size(); ++i) {
                    GeneralName gn = GeneralName.getInstance(as.getObjectAt(i));
                    switch (gn.getTagNo()) {
                    case 0:
                        asName = (ASN1Sequence) gn.getName();
                        strOID = ((DERObjectIdentifier) asName.getObjectAt(0)).getId();
                        strOtherName = decodeASN1String(((DERTaggedObject) asName.getObjectAt(1)).getObject());
                        oids.put(strOID, strOtherName);
                        break;
                    case 1:
                    	strOID = "";
                    	strOtherName = ((DERIA5String) gn.getName()).getString();
                    	oids.put(strOID, strOtherName);
                        break;
                    default:
                        break;
                    }
                }
            }
            
            Set<String> cc = oids.keySet();
        	for (String ch1:cc) {
				String info = oids.get(ch1);
				
				/*
				 * [JAD] 11/03/2020 - User Principal Name (UPN). A extensao subjectAlternateName
				 * deve estar presente em certificados usados para smart card logon.
				 *  rfc822Name: cont�m o endere�o e-mail do titular do certificado.
				 *  OID = 1.3.6.1.4.1.311.20.2.3 e conte�do = Nome Principal que cont�m o 
				 *  dom�nio de login em esta��es de trabalho (UPN).
				 */
				if(ch1.equalsIgnoreCase("1.3.6.1.4.1.311.20.2.3")) {
					logger.debug("OID de UPN encontrado.");
					return info.trim();
				}
        	}
        	
		} catch (CertificateEncodingException e) {
			logger.error("Erro codificando certificado");
			logger.error(e);
		} catch (IOException e) {
			logger.error("Erro I/O decodificando objeto DER.");
			logger.error(e);
		}
		logger.debug("OID de UPN nao foi encontrado.");
		return "";
	}
	
	/**
	 * [JAD] 10/03/2020
	 * Busca o OID da politica de certificados da Caixa e do Serpro retornando true em caso positivo para ambos
	 * @param cert
	 * @return boolean
	 */
	public boolean validaCaixaPFA3(X509Certificate cert) {
		boolean rval = false;
		logger.debug("Valida CAIXA A3 com certificado....");
		if (cert != null) {
			String issuer = cert.getIssuerX500Principal().getName();
			
			logger.debug("Verifica Certificado de Operador : " + cert.getSubjectDN());
				try {
					List<PolicyInformation> policies = getPolicies(cert);
					for (PolicyInformation pi : policies) {
//						[JAD] 07/02/2020 - as Politicas de certificado (PC) implementadas pela AC SERPRO RFB sao:
//								1. PC ACSERPRORFB A3 OID 2.16.76.1.2.3.4
//								2. PC ACSERPRORFB A1 OID 2.16.76.1.2.1.10
//						e as politicas da caixa sao:
//								1. PC AC CAIXA PF - A3  OID 2.16.76.1.2.3.8
//								2. PC AC CAIXA PJ - A3  OID 2.16.76.1.2.3.9
						
						boolean caixa = pi.getPolicyIdentifier().getId().equals("2.16.76.1.2.3.8");
						boolean serpro = pi.getPolicyIdentifier().getId().equals("2.16.76.1.2.3.4");
						
						if (caixa || serpro) {
							rval = true;
							break;
						}
					}
				} catch (IOException e) {
					logger.error("Erro Obtendo polices do certificado " + cert.toString());
				}
			}
		
		logger.debug("Resultado para validacao OID Caixa e Serpro: " + rval);
		return rval;
	}
	
	
	
	@SuppressWarnings("unchecked")
	private List<PolicyInformation> getPolicies(X509Certificate cert) throws IOException {
		List<PolicyInformation> rval = new ArrayList<PolicyInformation>();

		/*
		 * certificatePolicies ::= SEQUENCE SIZE (1..MAX) OF PolicyInformation
		 */
		DERObject obj = getExtensionValue(cert, X509Extensions.CertificatePolicies.getId());
		if (obj != null) {
			ASN1Sequence policies = ASN1Sequence.getInstance(obj);
			if (policies != null) {
				Enumeration<ASN1Sequence> policiesEnumeration = policies.getObjects();
				while (policiesEnumeration.hasMoreElements()) {
					PolicyInformation pi = PolicyInformation.getInstance(policiesEnumeration.nextElement());
					rval.add(pi);
				}
			}
		}
		return rval;
	}

}
